﻿using System;
using DotNet.Utilities;
using System.Data;
using Utility;
namespace FineUIMvc.EmptyProject
{
    public class CommonBll
    {
        #region 计算在线时间
        /// <summary>
        /// 计算当前用户在线时长
        /// </summary>
        /// <param name="startTime">用户登陆时间</param>
        /// <param name="endTime">用户离线时间</param>
        /// <returns></returns>
        public static string LoginDuration(string userid, object endTime)
        {
            object startTime;
            string sqlTxt = "SELECT MAX(LogDate) AS LOGTIME FROM dbo.LogDetails WHERE UserName  = '"+userid + "'";
            DataTable dt = DBConnSql.GetDataTable(AppConfiguration.SqlDefault, sqlTxt);
            startTime = dt.Rows[0][0];
            try
            {
                double minu = TimeHelper.DateDiff("n", TimeHelper.CDate(startTime), TimeHelper.CDate(endTime));
                if (minu < 1.0)
                {
                    return "小于1分钟";
                }
                return minu.ToString("0") + "分钟";
            }
            catch (Exception)
            {
                return "计算异常";
            }
        }
        #endregion

     
        #region  日志记录
        public static void WirteLogs(string pageName, string userId, string info2, string info3)
        {
        log4net.ILog log = log4net.LogManager.GetLogger(pageName);

            var ip = IpHelper.GetUserIp();

            //创建客户端信息获取实体
            //浏览器信息
            //var browerInfo = System.Web.HttpContext.Current.Request.Browser.Platform.ToString();
            //browerInfo = System.Web.HttpContext.Current.Request.Browser.Browser.ToString() + System.Web.HttpContext.Current.Request.Browser.Version.ToString();
            //browerInfo = System.Web.HttpContext.Current.Request.Browser.Platform;
            
            log.Info(new LogContent(ip, userId, info2, info3));
        }
            #endregion  日志记录
    }
}