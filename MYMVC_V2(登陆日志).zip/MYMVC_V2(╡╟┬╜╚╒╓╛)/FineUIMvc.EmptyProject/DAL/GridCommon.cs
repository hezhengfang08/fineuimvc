﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

namespace FineUIMvc.EmptyProject.DAL
{
    public static class GridCommon
    {
        /// <summary>
        /// 设置 FineUIMvc.Grid 表头信息
        /// </summary>
        /// <param name="dtHead"></param>
        /// <param name="FGrid"></param>
        public static void GridSetting(DataTable dtHead, FineUIMvc.Grid FGrid)
        {
            //设置行号列
            FineUIMvc.GridRow gr = new FineUIMvc.GridRow();
            FineUIMvc.RowNumberField RowFiled = new FineUIMvc.RowNumberField();
            RowFiled.EnablePagingNumber = true;
            RowFiled.MinWidth = 30;
            RowFiled.TextAlign = FineUIMvc.TextAlign.Center;
            FGrid.Columns.Insert(0, RowFiled);


            string sKey = "";
            //FineUIMvc.BoundField bf;
            FineUIMvc.RenderField bf;

            #region 循环取 dtHead 中的列信息
            int i = 1;
            foreach (DataRow dr in dtHead.Rows)
            {
                //bf = new FineUIMvc.BoundField();
                bf = new FineUIMvc.RenderField();
                bf.ColumnID = dr["Data_Field"].ToString();
                bf.DataField = dr["Data_Field"].ToString();
                bf.HeaderText = dr["Column_Name"].ToString();
                //bf.DataFormatString = dr["Data_Format"].ToString();
                bf.Width = Convert.ToInt32(dr["Column_Width"].ToString());
                if (bf.Width == 0)
                {
                    bf.MinWidth = 80;
                    bf.ExpandUnusedSpace = true;
                }
                else
                {
                    if (i == dtHead.Rows.Count)
                    {
                        bf.MinWidth = Convert.ToInt32(dr["Column_Width"].ToString());
                        bf.ExpandUnusedSpace = true;
                    }
                    else
                    {
                        bf.Width = Convert.ToInt32(dr["Column_Width"].ToString());
                    }
                }
                int iLock = Convert.ToInt32(dr["Column_Lock"].ToString());
                if (iLock == 1)
                {
                    bf.EnableLock = true;
                    bf.Locked = true;
                }
                int iKey = Convert.ToInt32(dr["Column_Key"].ToString());
                if (iKey == 1)
                {
                    if (sKey.Length > 0) sKey += ",";
                    sKey += bf.DataField;
                }
                int iHide = Convert.ToInt32(dr["Column_Hide"].ToString());
                if (iHide == 1)
                {
                    bf.Hidden = true;
                }

                FGrid.Columns.Insert(i, bf);
                i++;
            }
            #endregion

            //FGrid.DataKeyNames = new string[] { sKey };
            FGrid.Fields = new string[] { sKey };

            //统一属性设置
            FGrid.EnableTextSelection = true;
            FGrid.AutoScroll = true;
            FGrid.ShowBorder = true;
            //FGrid.AllowPaging = true;
            //FGrid.IsDatabasePaging = true;
            FGrid.AllowColumnLocking = true;
            FGrid.Margin = "2px";
        }

        #region "补充"
        public static GridColumn[] GridHeadColumns(DataTable dtHead, bool displayRowNumberField = false)
        {
            if (HasGroupClolumns(dtHead))
            {
                return GridTwoHeadColumns(dtHead, displayRowNumberField);
            }
            else return GridOneHeadColumns(dtHead, displayRowNumberField);
        }

        private static GridColumn[] GridOneHeadColumns(DataTable dtHead, bool displayRowNumberField = false)
        {
            List<GridColumn> columns = new List<GridColumn>();

            RenderField field = null;

            RowNumberField rownumberfield = new RowNumberField();
            rownumberfield.EnablePagingNumber = true;
            rownumberfield.Hidden = !displayRowNumberField;
            columns.Add(rownumberfield);

            foreach (DataRow dr in dtHead.Rows)
            {
                switch (dr["DATA_TYPE"].ToString().Trim())
                {
                    case "String":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        columns.Add(field);
                        break;
                    case "Int":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.Int;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        columns.Add(field);
                        break;
                    case "Date":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.Date;
                        field.Renderer = Renderer.Date;
                        field.RendererArgument = "yyyy-MM-dd";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        columns.Add(field);
                        break;
                    default:
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        columns.Add(field);
                        break;
                }
            }

            return columns.ToArray();
        }

        private static GridColumn[] GridTwoHeadColumns(DataTable dtHead)
        {
            List<GridColumn> columns = new List<GridColumn>();
            string sGroup_Name = "";
            string sLastGroup_Name = "";
            int iHide = 0;

            RenderField field = null;
            GroupField Gfield = null;


            foreach (DataRow dr in dtHead.Rows)
            {
                sGroup_Name = dr["GROUP_NAME"].ToString().Trim();

                if ((sLastGroup_Name == "") || (sLastGroup_Name != sGroup_Name))
                {
                    //中途变换Group，要把已绑定的组添加到列中
                    if (sLastGroup_Name != sGroup_Name)
                    {
                        if (Gfield != null) columns.Add(Gfield);
                    }

                    //还有新组，生成新组
                    Gfield = new GroupField();
                    Gfield.HeaderText = sGroup_Name;
                    Gfield.TextAlign = TextAlign.Center;
                    Gfield.EnableLock = true;

                    //将行号绑定到第一个组中
                    if (sLastGroup_Name == "")
                    {
                        RowNumberField rownumberfield = new RowNumberField();
                        rownumberfield.EnablePagingNumber = true;
                        Gfield.Columns.Add(rownumberfield);
                    }

                }


                switch (dr["DATA_TYPE"].ToString().Trim())
                {
                    case "String":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    case "Int":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.Int;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    case "Date":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.Int;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    default:
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                }

                sLastGroup_Name = sGroup_Name;

            }

            //中途没有变换组或还有组未添加的，将最后一个组加上
            if (Gfield != null) columns.Add(Gfield);

            return columns.ToArray();
        }

        private static GridColumn[] GridTwoHeadColumns(DataTable dtHead, bool displayRowNumberField)
        {
            List<GridColumn> columns = new List<GridColumn>();
            string sGroup_Name = "";
            string sLastGroup_Name = "";
            int iHide = 0;
            int i = 0;

            RenderField field = null;
            GroupField Gfield = null;


            foreach (DataRow dr in dtHead.Rows)
            {
                i = i + 1;

                //将行号单独一组
                if (i == 1)
                {
                    Gfield = new GroupField();
                    Gfield.HeaderText = sGroup_Name;
                    Gfield.TextAlign = TextAlign.Center;
                    Gfield.EnableLock = true;

                    RowNumberField rownumberfield = new RowNumberField();
                    rownumberfield.EnablePagingNumber = true;
                    rownumberfield.Hidden = !displayRowNumberField;
                    Gfield.Columns.Add(rownumberfield);
                    columns.Add(Gfield);
                }

                sGroup_Name = dr["GROUP_NAME"].ToString().Trim();

                if ((sLastGroup_Name == "") || (sLastGroup_Name != sGroup_Name))
                {
                    //中途变换Group，要把已绑定的组添加到列中
                    if ((sLastGroup_Name != sGroup_Name) && (i != 1))
                    {
                        if (Gfield != null) columns.Add(Gfield);
                    }

                    //还有新组，生成新组
                    Gfield = new GroupField();
                    Gfield.HeaderText = sGroup_Name;
                    Gfield.TextAlign = TextAlign.Center;
                    Gfield.EnableLock = true;
                }


                switch (dr["DATA_TYPE"].ToString().Trim())
                {
                    case "String":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    case "Int":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.Int;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    case "Date":
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();       
                        field.FieldType = FieldType.Date;
                        field.Renderer = Renderer.Date;
                        field.RendererArgument = "yyyy-MM-dd";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                    default:
                        field = new RenderField();
                        field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dr["DATA_FIELD"].ToString().Trim();
                        field.FieldType = FieldType.String;
                        //field.RendererFunction = "renderGender";
                        if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        else
                        { field.Width = 80; }
                        iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        if (iHide == 1) field.Hidden = true;
                        Gfield.Columns.Add(field);
                        break;
                }

                sLastGroup_Name = sGroup_Name;

            }

            //中途没有变换组或还有组未添加的，将最后一个组加上
            if (Gfield != null) columns.Add(Gfield);

            return columns.ToArray();
        }

        private static bool HasGroupClolumns(DataTable dtHead)
        {
            bool bResult = false;
            string sGroup_name = "";

            foreach (DataRow dr in dtHead.Rows)
            {
                sGroup_name = dr["GROUP_NAME"].ToString().Trim();
                if (sGroup_name != "")
                {
                    bResult = true;
                    break;
                }
            }

            return bResult;
        }

        /// <summary>
        /// 用于Grid头有两层的多表头
        /// </summary>
        /// <param name="hashTop">顶层的栏位Hashtable</param>
        /// <param name="hashtable">多表头的层间对应关系</param>
        /// <param name="dtHead">从存储过程取到的column参数时返回的表</param>
        /// <param name="LockGrpCols">冻结列的列名数组</param>
        /// <returns></returns>
        public static GridColumn[] GridTwoHeadColumns(Hashtable hashTop, Hashtable hashtable, DataTable dtHead, string[] LockGrpCols)
        {
            ArrayList al = new ArrayList(hashTop.Keys);
            al.Sort();

            List<GridColumn> columns = new List<GridColumn>();

            RenderField field = null;

            //RowNumberField rownumberfield = new RowNumberField();
            //rownumberfield.HeaderText = "序号";
            //rownumberfield.EnablePagingNumber = true;
            //columns.Add(rownumberfield);
            GroupField Gfield = null;

            //for (int i = 0; i < al.Count; i++)
            //{
            //    //Response.Write("键：" + al[i] + " 的值为：" + hashTop[al[i]].ToString() + "<br />");
            //    hashtable[al[i]].ToString();
            //}

            // 遍历哈希表
            //foreach (DictionaryEntry de in hashTop)
            for (int i = 0; i < al.Count; i++)
            {
                //Console.WriteLine("Key -- {0}; Value --{1}.", de.Key, de.Value);
                Gfield = new GroupField();
                Gfield.HeaderText = hashTop[al[i]].ToString(); // de.Value.ToString();
                Gfield.TextAlign = TextAlign.Center;
                Gfield.EnableLock = true;
                //if (LockGrpCols.Contains(hashTop[al[i]].ToString()))
                //{
                //    Gfield.Locked = true;
                //}

                foreach (DataRow dr in dtHead.Rows)
                {
                    bool UseGroup = true;
                    if (dtHead.Columns.Contains("GROUP_NAME"))
                    {
                        if (dr["GROUP_NAME"].ToString().Trim() == "")
                        {
                            UseGroup = false;
                        }
                    }

                    if (UseGroup == true)
                    {
                        if (hashtable[dr["COLUMN_NAME"].ToString().Trim()].ToString() == hashTop[al[i]].ToString().Trim())   //    de.Value.ToString().Trim())
                        {
                            field = new RenderField();
                            field.ColumnID = dr["COLUMN_NAME"].ToString().Trim();
                            field.HeaderText = dr["COLUMN_NAME"].ToString().Trim();
                            field.DataField = dr["DATA_FIELD"].ToString().Trim();
                            field.SortField = dr["DATA_FIELD"].ToString().Trim();
                            if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                            { field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                            else
                            { field.Width = 80; }
                            int iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                            if (iHide == 1)
                            {
                                field.Hidden = true;
                            }
                            //field.EnableLock = true;
                            ////if (LockGrpCols.Contains(hashTop[al[i]].ToString()))
                            //if (LockGrpCols.Contains(dr["COLUMN_NAME"].ToString().Trim()))
                            //{
                            //    field.Locked = true;
                            //}
                            switch (dr["DATA_TYPE"].ToString().Trim())
                            {
                                case "String":
                                    field.FieldType = FieldType.String;
                                    break;
                                case "Int":
                                    field.FieldType = FieldType.Int;
                                    break;
                                case "Decimal":
                                    field.FieldType = FieldType.Double;
                                    break;
                                case "Date":
                                    field.FieldType = FieldType.Date;
                                    break;
                                default:
                                    field.FieldType = FieldType.String;
                                    break;
                            }
                            //columns.Add(field);
                            Gfield.Columns.Add(field);
                        }
                    }
                }

                //Gfield.Columns.Add()
                columns.Add(Gfield);
            }

            return columns.ToArray();
        }

        #endregion

        #region 
        /// <summary>
        /// 用于特定的【销售情况统计】存储过程没有columns,Grid头有两层的多表头的动态多表头
        /// </summary>
        /// <param name="hashTop">顶层的栏位Hashtable</param>
        /// <param name="hashtable">多表头的层间对应关系</param>
        /// <param name="dtHead">从存储过程取到的column参数时返回的表</param>
        /// <param name="LockGrpCols">冻结列的列名数组</param>
        /// <returns></returns>
        public static GridColumn[] GridTwoHeadColumnsWithNoProceColumns(Hashtable hashTop, Hashtable hashtable, DataTable dtList, string[] LockGrpCols)
        {
            ArrayList al = new ArrayList(hashTop.Keys);
            al.Sort();

            List<GridColumn> columns = new List<GridColumn>();

            RenderField field = null;

            //RowNumberField rownumberfield = new RowNumberField();
            //rownumberfield.HeaderText = "序号";
            //rownumberfield.EnablePagingNumber = true;
            //columns.Add(rownumberfield);
            GroupField Gfield = null;

            //for (int i = 0; i < al.Count; i++)
            //{
            //    //Response.Write("键：" + al[i] + " 的值为：" + hashTop[al[i]].ToString() + "<br />");
            //    hashtable[al[i]].ToString();
            //}

            // 遍历哈希表
            //foreach (DictionaryEntry de in hashTop)
            for (int i = 0; i < al.Count; i++)
            {
                //Console.WriteLine("Key -- {0}; Value --{1}.", de.Key, de.Value);
                Gfield = new GroupField();
                Gfield.HeaderText = hashTop[al[i]].ToString(); // de.Value.ToString();
                Gfield.TextAlign = TextAlign.Center;
                Gfield.EnableLock = true;
                //if (LockGrpCols.Contains(hashTop[al[i]].ToString()))
                //{
                //    Gfield.Locked = true;
                //}

                foreach (DataColumn dc in dtList.Columns)
                {
                    //bool UseGroup = true;
                    //if (dtHead.Columns.Contains("GROUP_NAME"))
                    //{
                    //    if (dr["GROUP_NAME"].ToString().Trim() == "")
                    //    {
                    //        UseGroup = false;
                    //    }
                    //}

                    string strcolumnname = dc.ColumnName;
                    //if (strcolumnname != "YEARMONTH" & strcolumnname != "SUM_QTY" & strcolumnname != "SUM_MONEY_QTY" & strcolumnname != "SUM_RATE")
                    //{
                    //if (dc.ColumnName.Contains("QTY") & !dc.ColumnName.Contains("MONEY"))
                    //{ strcolumnname = dc.ColumnName.Split('_')[0] + "数量"; }
                    //if (dc.ColumnName.Contains("MONEY_QTY"))
                    //{ strcolumnname = dc.ColumnName.Split('_')[0] + "金额"; }
                    //if (dc.ColumnName.Contains("RATE"))
                    //{ strcolumnname = dc.ColumnName.Split('_')[0] + "达成率"; }
                    //    strcolumnname = dc.ColumnName;
                    //}
                    //if (UseGroup == true)
                    //{
                    if (hashtable[strcolumnname].ToString() == hashTop[al[i]].ToString().Trim())   //    de.Value.ToString().Trim())
                    {
                        field = new RenderField();
                        field.ColumnID = dc.ColumnName.ToString();
                        field.HeaderText = dc.ColumnName.ToString();// dr["COLUMN_NAME"].ToString().Trim();
                        field.DataField = dc.ColumnName.ToString();//  dr["DATA_FIELD"].ToString().Trim();
                        field.SortField = dc.ColumnName.ToString();//  dr["DATA_FIELD"].ToString().Trim();
                        //if (dr["COLUMN_WIDTH"].ToString().Trim() != "0")
                        //{ field.Width = Convert.ToInt32(dr["COLUMN_WIDTH"].ToString().Trim()); }
                        //else
                        //{ 
                        field.Width = 80;
                        //}
                        //int iHide = Convert.ToInt32(dr["COLUMN_HIDE"].ToString());
                        //if (iHide == 1)
                        //{
                        //    field.Hidden = true;
                        //}
                        //field.EnableLock = true;
                        ////if (LockGrpCols.Contains(hashTop[al[i]].ToString()))
                        //if (LockGrpCols.Contains(dr["COLUMN_NAME"].ToString().Trim()))
                        //{
                        //    field.Locked = true;
                        //}
                        //switch (dr["DATA_TYPE"].ToString().Trim())
                        //{
                        //    case "String":
                        field.FieldType = FieldType.String;
                        //        break;
                        //    case "Int":
                        //        field.FieldType = FieldType.Int;
                        //        break;
                        //    case "Decimal":
                        //        field.FieldType = FieldType.Double;
                        //        break;
                        //    case "Date":
                        //        field.FieldType = FieldType.Date;
                        //        field.Renderer = Renderer.Date;
                        //        field.RendererArgument = "yyyy-MM-dd";
                        //        break;
                        //    default:
                        //        field.FieldType = FieldType.String;
                        //        break;
                        //}
                        //columns.Add(field);
                        Gfield.Columns.Add(field);
                    }
                }
                //}

                //Gfield.Columns.Add()
                columns.Add(Gfield);
            }

            return columns.ToArray();
        }
   #endregion

    }
}