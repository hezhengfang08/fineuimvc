﻿using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Data.SqlClient;
using Utility;
namespace FineUIMvc.EmptyProject.DAL
{
    public class QueryCommon
    {
        #region SQL Server 操作类
        /// <summary>
        /// 通用存储过程查询 For SQL
        /// </summary>
        /// <param name="connStr"></param>
        /// <param name="sp_name"></param>
        /// <param name="p_type"></param>
        /// <param name="p_pageindex"></param>
        /// <param name="p_pagesize"></param>
        /// <param name="p_condition"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string connStr, string sp_name, string p_type, int p_pageindex, int p_pagesize, string p_condition, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }


            SqlParameter[] para = new SqlParameter[iKeyLen + 4];
            para[0] = new SqlParameter("@p_type", SqlDbType.VarChar);
            para[0].Value = p_type;
            para[1] = new SqlParameter("@p_pageindex", SqlDbType.Int);
            para[1].Value = p_pageindex;
            para[2] = new SqlParameter("@p_pagesize", SqlDbType.Int);
            para[2].Value = p_pagesize;
            para[3] = new SqlParameter("@p_condition", SqlDbType.VarChar);
            para[3].Value = p_condition;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new SqlParameter("@p_key" + (i + 1), SqlDbType.VarChar);
                para[4 + i].Value = key[i];
            }

            return DBConnSql.execPro_DT(connStr, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询 For SQL
        /// </summary>
        /// <param name="connStr">数据库连接</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="p_pagesize">每页显示数</param>
        /// <param name="p_pageindex">当前页序</param>
        /// <param name="p_condition">查询条件（SQL 组合语句）</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResultSQL(string connStr, string sp_name, string p_type, int p_pageindex, int p_pagesize, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }


            SqlParameter[] para = new SqlParameter[iKeyLen + 3];
            para[0] = new SqlParameter("@p_type", SqlDbType.VarChar);
            para[0].Value = p_type;
            para[1] = new SqlParameter("@p_pageindex", SqlDbType.Int);
            para[1].Value = p_pageindex;
            para[2] = new SqlParameter("@p_pagesize", SqlDbType.Int);
            para[2].Value = p_pagesize;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[3 + i] = new SqlParameter("@p_key" + (i + 1), SqlDbType.VarChar);
                para[3 + i].Value = key[i];
            }

            return DBConnSql.execPro_DT(connStr, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="connStr">数据库连接</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResultSQL(string connStr, string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            SqlParameter[] para = new SqlParameter[iKeyLen + 3];
            para[0] = new SqlParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new SqlParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = 0;
            para[2] = new SqlParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = 0;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[3 + i] = new SqlParameter("p_key" + (i + 1), SqlDbType.VarChar);
                para[3 + i].Value = key[i];
            }

            return DBConnSql.execPro_DT(connStr, sp_name, para);
        }

        /// <summary>
        /// 执行存储过程，返回执行提示．
        /// </summary>
        /// <param name="connStr">数据库连接</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">类型</param>
        /// <param name="key">参数集</param>
        /// <returns></returns>
        public static DataTable GetDoResultSQL(string connStr, string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            SqlParameter[] para = new SqlParameter[iKeyLen + 1];
            para[0] = new SqlParameter("p_type", SqlDbType.VarChar);
            para[0].Value = p_type;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[1 + i] = new SqlParameter("p_key" + (i + 1), SqlDbType.VarChar);
                para[1 + i].Value = key[i];
            }

            return DBConnSql.execPro_DT(connStr, sp_name, para);
        }
        #endregion


        #region Oracle 操作类
        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="p_pagesize">每页显示数</param>
        /// <param name="p_pageindex">当前页序</param>
        /// <param name="p_condition">查询条件（SQL 组合语句）</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string sp_name, string p_type, int p_pageindex, int p_pagesize, string p_condition, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = p_pageindex;
            para[2] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = p_pagesize;
            para[3] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[3].Value = p_condition;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[4 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="p_pagesize">每页显示数</param>
        /// <param name="p_pageindex">当前页序</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string sp_name, string p_type, int p_pageindex, int p_pagesize, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = p_pageindex;
            para[2] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = p_pagesize;
            para[3] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[3].Value = "1=1";

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[4 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = 1;
            para[2] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = 99999;
            para[3] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[3].Value = "1=1";

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[4 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="p_pagesize">每页显示数</param>
        /// <param name="p_pageindex">当前页序</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string connStr, string sp_name, string p_type, int p_pageindex, int p_pagesize, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = p_pageindex;
            para[2] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = p_pagesize;
            para[3] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[3].Value = "1=1";

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[4 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(connStr, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询
        /// </summary>
        /// <param name="connStr">数据库链接字符串</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="key">参数数组，最大长度参考配置文件</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string connStr, string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[1].Value = 1;
            para[2] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[2].Value = 9999;
            para[3] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[3].Value = "1=1";

            for (int i = 0; i < iKeyLen; i++)
            {
                para[4 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[4 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(connStr, sp_name, para);
        }



        /// <summary>
        /// 执行存储过程，返回执行提示．
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">类型</param>
        /// <param name="key">参数集</param>
        /// <returns></returns>
        public static DataTable GetDoResult(string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 1];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[1 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[1 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
        }

        /// <summary>
        /// 执行存储过程，返回执行提示．
        /// </summary>
        /// <param name="connStr">数据库连接</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">类型</param>
        /// <param name="key">参数集</param>
        /// <returns></returns>
        public static DataTable GetDoResult(string connStr, string sp_name, string p_type, string[] key)
        {
            int iKeyLen = (key == null) ? 0 : key.Length;

            if (iKeyLen > AppConfiguration.ParameterCount)
            {
                return null;
            }

            OracleParameter[] para = new OracleParameter[iKeyLen + 1];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;

            for (int i = 0; i < iKeyLen; i++)
            {
                para[1 + i] = new OracleParameter("p_key" + (i + 1), OracleDbType.Varchar2);
                para[1 + i].Value = key[i];
            }

            return DBConnOracle.execPro_DT(connStr, sp_name, para);
        }
        #endregion



        /*
        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="p_condition">查询条件（SQL 组合语句）</param>
        /// <param name="p_pagesize">每页显示数</param>
        /// <param name="p_pageindex">当前页序</param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string sp_name, string p_type, string key1, string key2, string key3, string p_condition, int p_pagesize, int p_pageindex)
        {
            OracleParameter[] para = new OracleParameter[7];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_key1", OracleDbType.Varchar2);
            para[1].Value = key1;
            para[2] = new OracleParameter("p_key2", OracleDbType.Varchar2);
            para[2].Value = key2;
            para[3] = new OracleParameter("p_key3", OracleDbType.Varchar2);
            para[3].Value = key3;
            para[4] = new OracleParameter("p_condition", OracleDbType.Varchar2);
            para[4].Value = p_condition;
            para[5] = new OracleParameter("p_pagesize", OracleDbType.Int32);
            para[5].Value = p_pagesize;
            para[6] = new OracleParameter("p_pageindex", OracleDbType.Int32);
            para[6].Value = p_pageindex;

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
        }

        /// <summary>
        /// 通用存储过程查询 For Oracle
        /// </summary>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="p_type">操作项标识</param>
        /// <param name="key1"></param>
        /// <param name="key2"></param>
        /// <param name="key3"></param>
        /// <returns></returns>
        public static DataTable GetQueryResult(string sp_name, string p_type, string key1, string key2, string key3)
        {
            OracleParameter[] para = new OracleParameter[4];
            para[0] = new OracleParameter("p_type", OracleDbType.Varchar2);
            para[0].Value = p_type;
            para[1] = new OracleParameter("p_key1", OracleDbType.Varchar2);
            para[1].Value = key1;
            para[2] = new OracleParameter("p_key2", OracleDbType.Varchar2);
            para[2].Value = key2;
            para[3] = new OracleParameter("p_key3", OracleDbType.Varchar2);
            para[3].Value = key3;

            return DBConnOracle.execPro_DT(AppConfiguration.ERPDBOracle, sp_name, para);
            //return DBConnOracle.execPro_Scalar(AppConfiguration.ERPDBOracle, sp_name, para);
        }
        */

        /// <summary>
        /// 获取当前用户是有具有指定项权限
        /// </summary>
        /// <param name="roleNo">指定权限值</param>
        /// <returns></returns>
        //public static bool HasPower(string roleNo)
        //{
        //    PowerClient power = new PowerClient();
        //    string sUserName = CookieName.GetCookieUserName();

        //    return power.HasPower(AppConfiguration.SYSTEM_FLAG, sUserName, roleNo);
        //}

    }
}