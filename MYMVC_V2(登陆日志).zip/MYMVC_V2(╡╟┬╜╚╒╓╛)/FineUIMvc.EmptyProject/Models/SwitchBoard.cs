﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FineUIMvc.EmptyProject.Models
{
    public class SwitchBoard : IKeyID
    {
        [Key]
        public int ID { get; set; }

        [StringLength(50)]
        public string PanelName { get; set; }

        [Display(Name = "面板名称")]


        public int PanelID { get; set; }
        [Display(Name = "面版ID")]
        [Required]

        public int systemID { get; set; }
        [Display(Name = "系统ID")]
        [Required]


        public string sytemName { get; set; }
        [Display(Name = "系统名称")]
        [StringLength(50)]
        [Required]


        public virtual ICollection<User> Users { get; set; }
    }
}