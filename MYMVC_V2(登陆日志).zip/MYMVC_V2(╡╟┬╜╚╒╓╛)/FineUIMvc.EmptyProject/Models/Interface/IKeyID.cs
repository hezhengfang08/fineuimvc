﻿namespace FineUIMvc.EmptyProject.Models
{
    public interface IKeyID
    {
        int ID { get; set; }

    }
}

