﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FineUIMvc.EmptyProject.Models
{
    public class Model:IKeyID
    {
        [Key]
        public int ID { get; set; }

        public string KEYID { get; set; }
        [Display(Name = "品号")]
        [StringLength(50)]
        [Required]
        public string PARTNO { get; set; }

        [Display(Name = "品名")]
        [StringLength(100)]
        public string PART_NAME { get; set; }

        [Display(Name = "规格")]
        [StringLength(100)]
        public string PART_SPEC { get; set; }

        [Display(Name = "客户料号")]
        [StringLength(50)]
        [Required]
        public string CUST_PARTNO { get; set; }  

        [Display(Name = "机型代码")]
        [StringLength(50)]
        [Required]
        public string MODEL_CODE { get; set; }

   
        [Display(Name = "Description")]
        public string MODEL_DESC { get; set; }

        [Display(Name = "客户名称")]
        public string CUST_NAME { get; set; }

        [Display(Name = "客户代码")]
        public string CUST_CODE { get; set; }

        [Display(Name = "客户名称")]
        public string MODEL_VERSION { get; set; }

        [Display(Name ="净重")]
        public Double NWKG { get; set; }

        [Display(Name = "毛重")]
        public Double GWKG { get; set; }
        [Display(Name = "体积")]
        public Double CBM { get; set; }
    }
}