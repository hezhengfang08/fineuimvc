﻿using System;

namespace FineUIMvc.EmptyProject.Views.other
{
    public partial class CharSum1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}