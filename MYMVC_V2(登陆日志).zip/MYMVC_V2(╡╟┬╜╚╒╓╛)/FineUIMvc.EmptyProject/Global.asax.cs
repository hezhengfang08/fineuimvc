﻿using log4net.Config;
using Newtonsoft.Json.Linq;
using System.Web.Mvc;
using System.Web.Routing;

namespace FineUIMvc.EmptyProject
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {   //应用程序启动时，自动加载配置log4Net
            XmlConfigurator.Configure();
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            
            ModelBinders.Binders.Add(typeof(JArray), new JArrayModelBinder());
            ModelBinders.Binders.Add(typeof(JObject), new JObjectModelBinder());

        }
    }
}
