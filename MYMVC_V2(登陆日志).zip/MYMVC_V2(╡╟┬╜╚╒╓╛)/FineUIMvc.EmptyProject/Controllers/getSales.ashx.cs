﻿using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Web.Script.Serialization;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Collections;
namespace FineUIMvc.EmptyProject.Controllers
{
    /// <summary>
    /// getSales 的摘要说明
    /// </summary>
    public class getSales : IHttpHandler
    {
        #region 全局变量
        JavaScriptSerializer jsS = new JavaScriptSerializer();
        List<object> lists = new List<object>();
        //Series seriesObj = new Series();
        string result = "";
        #endregion 全局变量
        public void ProcessRequest(HttpContext context)
        {
            //获取一同发送过来的参数
            //string command = context.Request["cmd"];
            context.Response.ContentType = "text/plain";
            //用来传回去的内容
            //context.Response.Write("Hello World");
            //Get_Data01(context);  //固定写死
            //Get_Data02(context);  //动态生成，没有调用基类
            Get_Data03(context);  //动态生成， 调用基类
        }


        //固定的列的取法
        public void Get_Data01(HttpContext context)
        {

            
            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";
            string sp_name = "P_MA_SACUR_LIST";
            string[] param = new string[2];
            param[0] = "S60";
            param[1] = "2017-06-01";
           

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            DataSet ds = new DataSet();
            ds.Tables.Add(dt.Copy());
            lists = new List<object>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                var obj = new { Dept= dr[0], Qty1 = dr[2] , Qty2 = dr[3]};
                lists.Add(obj);
            }
            jsS = new JavaScriptSerializer();
            result = jsS.Serialize(lists);
            context.Response.Write(result);
        }


        //动态返回所有的列
        public void Get_Data02(HttpContext context)
        {


            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";
            string sp_name = "P_MA_SACUR_LIST";
            string[] param = new string[2];
            param[0] = "S10";
            param[1] = "2017-06-01";


            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();

                //List<object> t = new List<object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);

                }
                arrayList.Add(dictionary);

            }

            jsS = new JavaScriptSerializer();
            result = jsS.Serialize(arrayList);
            context.Response.Write(result);
        }

        //直接调用JSONHELP 基类的方法
        public void Get_Data03(HttpContext context)
        {


            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";
            string sp_name = "P_MA_SACUR_LIST";
            string[] param = new string[2];
            param[0] = "S10";
            param[1] = "2017-06-01";


            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            JsonHelper jsHelper = new JsonHelper();
            result = jsHelper.ToJson(dt);
            context.Response.Write(result);
        }

        /// <summary>
        /// 把DataTable对象转成json字符串
        /// </summary> 
        public static string ToJson(DataTable dt)
        {
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            ArrayList arrayList = new ArrayList();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                arrayList.Add(dictionary);
            }
            return javaScriptSerializer.Serialize(arrayList);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}