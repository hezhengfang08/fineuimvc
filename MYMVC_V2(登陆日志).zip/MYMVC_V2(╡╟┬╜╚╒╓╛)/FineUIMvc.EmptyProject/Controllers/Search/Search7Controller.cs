﻿using System;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.Search
{
    public class Search7Controller : BaseController
    {
        // GET: Search7
        public ActionResult MA_SASAD()
        {

            string sp_name1 = "P_MA_SASAD_LIST";
            string sp_name2 = "P_MA_SASSG_LIST";
            string sp_name3 = "P_MA_SASSM_LIST";
            string sp_name4 = "P_MA_SASSC_LIST";
            string sp_name5 = "P_MA_SASSS_LIST";
            string sp_name6 = "P_MA_SASAD_LIST";



            string[] param = new string[3];
            param[0] = "S10";
            param[1] = "2017-06-01";
            param[2] = "2017-12-01";
            BindGrid1(sp_name1, param);
            BindGrid(sp_name2, param);
            BindGrid(sp_name3, param);
            BindGrid(sp_name4, param);
            BindGrid(sp_name5, param);
            BindGrid(sp_name6, param);
            //下拉框
            BindDDL_List();
            
            return View();
           
        }

        #region 下拉框
        private void BindDDL_List(string[] key = null)
        {
            DataTable dt = QueryCommonTst.GetQueryResult("P_DROPDOWN_LIST", "site", key);
           
            ViewBag.ddl_SiteDataSource = dt;
          
        }
        #endregion 下拉框

        #region 选项卡改变事件
        [HttpPost]
        [ValidateAntiForgeryToken]
        //一
        public ActionResult TabStrip1_TabIndexChanged(int activeIndex)
        {
            ViewBag.Current = activeIndex + 1;
            if (activeIndex == 0)
            {
                string sp_name = "P_MA_SASSD_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "ALL";
                BindGrid1(sp_name, param);
            }
            else if (activeIndex == 1)
            {
                string sp_name = "P_MA_SASSG_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "ALL";
                BindGrid(sp_name, param);
            }
           

            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        //二
        public ActionResult TabStrip2_TabIndexChanged(int activeIndex)
        {
            ViewBag.Current = activeIndex + 3;
            if (activeIndex == 0)
            {
                string sp_name = "P_MA_SASSM_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "S10";
                BindGrid(sp_name, param);

            }
            else if (activeIndex == 1)
            {
                string sp_name = "P_MA_SASSC_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "S10";
                BindGrid(sp_name, param);
            }
            else if (activeIndex == 2)
            {
                string sp_name = "P_MA_SASSS_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "S10";
                BindGrid(sp_name, param);
            }
            else if (activeIndex == 3)
            {
                string sp_name = "P_MA_SASAD_LIST";
                BindDDL_List();
                string[] param = new string[1];
                param[0] = "S10";
                BindGrid(sp_name, param);
            }


            return UIHelper.Result();
        }

        #endregion 选项卡改变事件

        #region 数据绑定
        private void BindGrid1(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

           

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            
           
            //表内容
            ViewBag.Grid1DataSource = dt;

        }

        private void BindGrid(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";
            //表内容
            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
           
            

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            
            switch (sp_name)
            {
                case "P_MA_SASSG_LIST":
                    //表头
                    ViewBag.Grid2Columns = GridCommon.GridHeadColumns(dtHead);
                    //表记录
                    ViewBag.Grid2RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
                    //表内容
                    ViewBag.Grid2DataSource = dt;
                    break;
                case "P_MA_SASSM_LIST":
                    //表头
                    ViewBag.Grid3Columns = GridCommon.GridHeadColumns(dtHead);
                    //表记录
                    ViewBag.Grid3RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
                    //表内容
                    ViewBag.Grid3DataSource = dt;
                    break;
                case "P_MA_SASSC_LIST":
                    //表头
                    ViewBag.Grid4Columns = GridCommon.GridHeadColumns(dtHead);
                    //表记录
                    ViewBag.Grid4RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
                    //表内容
                    ViewBag.Grid4DataSource = dt;
                    break;
                case "P_MA_SASSS_LIST":
                    //表头
                    ViewBag.Grid5Columns = GridCommon.GridHeadColumns(dtHead);
                    //表记录
                    ViewBag.Grid5RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
                    //表内容
                    ViewBag.Grid5DataSource = dt;
                    break;
                case "P_MA_SASAD_LIST":
                    //表头
                    ViewBag.Grid6Columns = GridCommon.GridHeadColumns(dtHead);
                    //表记录
                    ViewBag.Grid6RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
                    //表内容
                    ViewBag.Grid6DataSource = dt;
                    break;
                default:
                    break;

            }

        }
        #endregion 数据绑定

        #region 查询数据 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid_ReBindGrid(JArray fields, JArray fields2, int index1, int index2,  int pageIndex, int pageSize, string txtSite, string txtDate1, string txtDate2)
        {
            string sp_name = "";
            string sp_name2 = "";
            FineUIMvc.GridAjaxHelper grid ;
            FineUIMvc.GridAjaxHelper grid2;

            switch (index1)
            {
                case 1:

                    grid = UIHelper.Grid("Grid1");
                    sp_name = "P_MA_SASSD_LIST";
                    break;
                case 2: 
                    grid = UIHelper.Grid("Grid2");
                    sp_name = "P_MA_SASSG_LIST";
                    break;
                default:
                    grid = UIHelper.Grid("Grid1");
                    sp_name = "P_MA_SASSD_LIST";
                    break;
            }
            switch (index2)
            {
                case 3:
                    grid2 = UIHelper.Grid("Grid3");
                    sp_name2 = "P_MA_SASSM_LIST";
                    break;
                case 4:
                    grid2 = UIHelper.Grid("Grid4");
                    sp_name2 = "P_MA_SASSC_LIST";
                    break;
                case 5:
                    grid2 = UIHelper.Grid("Grid5");
                    sp_name2 = "P_MA_SASSS_LIST";
                    break;
                case 6:
                    grid2 = UIHelper.Grid("Grid6");
                    sp_name2 = "P_MA_SASAD_LIST";
                    break;
                default:
                    grid2 = UIHelper.Grid("Grid1");
                    sp_name2 = "P_MA_SASSD_LIST";
                    break;
            }

            string text = txtDate1.Substring(1, 24);
            string txtBegin = Convert.ToDateTime(txtDate1.Substring(0,24)).ToString("yyyy-MM-dd");
            string txtEnd = Convert.ToDateTime(txtDate2.Substring(0, 24)).ToString("yyyy-MM-dd");

            string[] aryKey = new string[3];
            aryKey[0] = txtSite;
            aryKey[1] = txtBegin;
            aryKey[2] = txtEnd;
                       
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", pageIndex + 1, pageSize, WhereStr, aryKey);
            DataTable dt2 = QueryCommonTst.GetQueryResult(sp_name2, "list", pageIndex + 1, pageSize, WhereStr, aryKey);
            //表记录
            int count1 = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);
            int count2 = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name2, "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);

            // 1.设置总项数（数据库分页回发时，如果总记录数不变，可以不设置RecordCount）
            grid.RecordCount(count1);
            grid2.RecordCount(count2);

            // 2. 设置每页显示项数（每页记录数改变时，要设置PageSize）
            grid.PageSize(pageSize);
            grid2.PageSize(pageSize);

            grid.DataSource(dt, fields);
            grid2.DataSource(dt2, fields2);
            return UIHelper.Result();
        }
        #endregion 查询数据

        #region 导出excel
        public ActionResult Grid_BtnExport(int index1, int index2, string txtSite, string txtDate1, string txtDate2)
        {
            string sp_name = "";
            string sp_name2 = "";
   
            switch (index1)
            {
                case 1:
                    sp_name = "P_MA_SASSD_LIST";
                    break;
                case 2:       
                    sp_name = "P_MA_SASSG_LIST";
                    break;
                default:
                    sp_name = "P_MA_SASSD_LIST";
                    break;
            }
            switch (index2)
            {
                case 3:          
                    sp_name2 = "P_MA_SASSM_LIST";
                    break;
                case 4:
                    sp_name2 = "P_MA_SASSC_LIST";
                    break;
                case 5:
                    sp_name2 = "P_MA_SASSS_LIST";
                    break;
                case 6:         
                    sp_name2 = "P_MA_SASAD_LIST";
                    break;
                default:                  
                    sp_name2 = "P_MA_SASSD_LIST";
                    break;
            }
            string txtBegin = Convert.ToDateTime(txtDate1.Substring(0, 24)).ToString("yyyy-MM-dd");
            string txtEnd = Convert.ToDateTime(txtDate2.Substring(0, 24)).ToString("yyyy-MM-dd");

            string[] aryKey = new string[3];
            aryKey[0] = txtSite;
            aryKey[1] = txtBegin;
            aryKey[2] = txtEnd;
            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "export", 1, 99999, "1=1", aryKey);
            DataTable dt2 = QueryCommonTst.GetQueryResult(sp_name2, "export", 1, 99999, "1=1", aryKey);
            var fileName = Server.MapPath("~/Files/"+sp_name+".xlsx");
            var fileName2 = Server.MapPath("~/Files/" + sp_name2 + ".xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            OperateExcel.CreateExcel(dt2, fileName2);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Application app2 = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            Microsoft.Office.Interop.Excel.Workbook wkb2 = app.Workbooks.Add(fileName2);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            app2.Visible = true;
            return UIHelper.Result();

        }
        #endregion
    }
}