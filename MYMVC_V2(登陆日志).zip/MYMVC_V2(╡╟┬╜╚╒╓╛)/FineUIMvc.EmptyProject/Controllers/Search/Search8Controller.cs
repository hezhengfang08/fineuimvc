﻿using System.Web.Mvc;

namespace FineUIMvc.EmptyProject.Controllers.Search
{
    public class Search8Controller : BaseController
    {
        // GET: Search8
        public ActionResult MA_SASAD2()
        {
            return View();
        }

        #region 选项卡改变事件
        [HttpPost]
        [ValidateAntiForgeryToken]
        //一
        public ActionResult TabStrip1_TabIndexChanged(int activeIndex)
        {
            //ViewBag.Current = activeIndex + 1;
            //if (activeIndex == 0)
            //{
            //    string sp_name = "P_MA_SASSD_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "ALL";
            //    BindGrid1(sp_name, param);
            //}
            //else if (activeIndex == 1)
            //{
            //    string sp_name = "P_MA_SASSG_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "ALL";
            //    BindGrid(sp_name, param);
            //}


            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        //二
        public ActionResult TabStrip2_TabIndexChanged(int activeIndex)
        {
            //ViewBag.Current = activeIndex + 3;
            //if (activeIndex == 0)
            //{
            //    string sp_name = "P_MA_SASSM_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "S10";
            //    BindGrid(sp_name, param);

            //}
            //else if (activeIndex == 1)
            //{
            //    string sp_name = "P_MA_SASSC_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "S10";
            //    BindGrid(sp_name, param);
            //}
            //else if (activeIndex == 2)
            //{
            //    string sp_name = "P_MA_SASSS_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "S10";
            //    BindGrid(sp_name, param);
            //}
            //else if (activeIndex == 3)
            //{
            //    string sp_name = "P_MA_SASAD_LIST";
            //    BindDDL_List();
            //    string[] param = new string[1];
            //    param[0] = "S10";
            //    BindGrid(sp_name, param);
            //}


            return UIHelper.Result();
        }

        #endregion 选项卡改变事件


    }
}