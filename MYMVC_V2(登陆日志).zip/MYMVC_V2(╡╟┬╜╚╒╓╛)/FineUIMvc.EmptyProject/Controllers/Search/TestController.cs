﻿using System;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.Search
{
    public class TestController : BaseController
    {
        // GET: Test
        public ActionResult test()
        {
            //string sp_name = "P_SY_QNND_LIST";
            
            //string[] param = new string[1];
            //param[0] = "ALL";
            //BindGrid(sp_name, param);
            return View();
        }

        #region
        private void BindGrid(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

        }
#endregion 绑定数据
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult btnGetSelection_Click(JArray DropDownBox1, string DropDownBox1_text, bool DropDownBox1_isUserInput)
        {
            var labResult = UIHelper.Label("labResult");
            if (!DropDownBox1_isUserInput)
            {
                labResult.Text(String.Format("下拉框文本：{0}（值：{1}）", DropDownBox1_text, String.Join(",", DropDownBox1)));
            }
            else
            {
                labResult.Text(String.Format("用户输入值：{0}", DropDownBox1_text));
            }

            return UIHelper.Result();
        }


    }
}