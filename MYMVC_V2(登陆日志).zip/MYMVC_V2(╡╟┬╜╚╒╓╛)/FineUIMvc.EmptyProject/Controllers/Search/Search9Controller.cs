﻿using System;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.Search
{
    public class Search9Controller : BaseController
    {
        // GET: Search9
        public ActionResult MX_BCOST()
        {
            string sp_name = "P_MX_BCOST_LIST";
            BindDDL_List();
            string[] param = new string[2];
            param[0] = "S60";
            //param[1] = "101101180169";
            BindGrid(sp_name, param);
            return View();
    
        }

        #region 下拉框
        private void BindDDL_List(string[] key = null)
        {
            DataTable dt = QueryCommonTst.GetQueryResult("P_DROPDOWN_LIST", "site2", key);
            ViewBag.ddl_SiteDataSource = dt;
        }
        #endregion 下拉框
        #region 绑定数据
        private void BindGrid(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 999;
            string WhereStr = " 1=1 ";

            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

            ViewBag.Grid1SummaryData = GetSummaryData(dt);

        }
        #endregion 绑定数据


        #region 总计信息

        private JObject GetSummaryData(DataTable source)
        {
            

            float MA_UNIT_QTYTotal = 0.0f;
           
            foreach (DataRow row in source.Rows)
            {
                MA_UNIT_QTYTotal += Convert.ToInt32(row["MA_UNIT_QTY"]);
                
            }


            JObject summary = new JObject();
            //summary.Add("major", "全部合计");
            summary.Add("MA_UNIT_QTY", MA_UNIT_QTYTotal.ToString("F2"));
           
            return summary;
        }
        #endregion 总计信息


        #region 查询 (普通）
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid1_ReBindGrid(JArray fields, string sp_name, int pageIndex, int pageSize, string txtSite, string txtPartno)
        {
            var grid1 = UIHelper.Grid("Grid1");

            if (txtPartno == "") { txtPartno = null; }
            string[] aryKey = new string[2];
            aryKey[0] = txtSite;
            aryKey[1] = txtPartno;
           
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", pageIndex + 1, 999, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);

            // 1.设置总项数（数据库分页回发时，如果总记录数不变，可以不设置RecordCount）
            grid1.RecordCount(ViewBag.Grid1RecordCount);

            // 2. 设置每页显示项数（每页记录数改变时，要设置PageSize）
            grid1.PageSize(pageSize);


            grid1.DataSource(dt, fields);
            ViewBag.Grid1SummaryData = GetSummaryData(dt);
            grid1.SummaryData(ViewBag.Grid1SummaryData);
            return UIHelper.Result();
        }
        #endregion 查询 (普通）

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string sp_name, string txtSite, string txtPartno)
        {

            string[] aryKey = new string[2];
            aryKey[0] = txtSite;
            aryKey[1] = txtPartno;

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "export", 1, 99999, "1=1", aryKey);
            var fileName = Server.MapPath("~/Files/P_MX_BCOST_LIST.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion

    }
}