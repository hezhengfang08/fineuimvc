﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using System.Web.Security;
using System.Data.Entity;
using FineUIMvc.EmptyProject.Models;
namespace FineUIMvc.EmptyProject.Controllers
{
    [Authorize]
    public class HomeController : BaseController
    {
        // GET: Home

       
        #region 修改密码
        public ActionResult ChangePassword()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword_btnSave_OnClick(string tbxOldPassword, string tbxNewPassword, string tbxConfirmNewPassword)
        {
            // 检查当前密码是否正确
            string oldPass = tbxOldPassword.Trim();
            string newPass = tbxNewPassword.Trim();
            string confirmNewPass = tbxConfirmNewPassword.Trim();

            if (newPass != confirmNewPass)
            {
                UIHelper.TextBox("tbxConfirmNewPassword").MarkInvalid("确认密码和新密码不一致！");
            }
            else
            {
                User user = db.Users.Where(u => u.Name == User.Identity.Name).FirstOrDefault();

                if (user != null)
                {
                    if (!PasswordUtil.ComparePasswords(user.Password, oldPass))
                    {
                        UIHelper.TextBox("tbxOldPassword").MarkInvalid("当前密码不正确！");
                    }
                    else
                    {
                        user.Password = PasswordUtil.CreateDbPassword(newPass);
                        db.SaveChanges();

                        Alert.ShowInTop("修改密码成功！");
                    }
                }
            }

            return UIHelper.Result();
        }
        #endregion

        public ActionResult Index()
        {
            LoadData();
            return View();
        }

        #region 默认的tab
        public ActionResult DefaultTab()
        {
            return View();
        }
        #endregion
        #region Help

        // GET: Home/Help
        public ActionResult Help()
        {
            return View();
        }

        // GET: Home/HelpWanNianLi
        public ActionResult HelpWanNianLi()
        {
            return View();
        }

        // GET: Home/HelpJiSuanQi
        public ActionResult HelpJiSuanQi()
        {
            return View();
        }


        #endregion
        #region 主题控制器
        public ActionResult Themes()
        {
            return View();

        }
        #endregion
        #region 加载数据
        private void LoadData()
        {
            //用户可见的菜单列表
            List<EmptyProject.Models.Menu> menus = ResolveUserMenuList();
            if (menus.Count == 0)
            {
                Response.Write("系统管理员尚未给你配置菜单！");
                Response.End();

                return;
            }
            // by hzf 2017年6月2日20:29:10  
            Accordion accordionMenu = new Accordion();
            accordionMenu.ID = "accordion";
            accordionMenu.EnableFill = true;
            accordionMenu.ShowBorder = false;
            accordionMenu.ShowHeader = false;
            //ViewBag.MenuTreeNodes = GetTreeNodes(menus, menus[0]).ToArray();
            //ViewBag.MenuTreeNodes2 = GetTreeNodes(menus, menus[1]).ToArray();
            // var test = db.SwitchBoard.FirstOrDefault();
            foreach (var item in db.SwitchBoard.Where(m => m.systemID == 2).ToArray())
            {

                AccordionPane accordionPane = new AccordionPane();
                accordionPane.Layout = LayoutType.Fit;
                accordionPane.ShowBorder = false;
                accordionPane.BodyPadding = "2px 0 0 0";
                accordionPane.Title = item.PanelName.ToString();

                accordionMenu.Items.Add(accordionPane);
                Tree innerTree = new Tree();

                innerTree.ShowBorder = false;

                innerTree.ShowHeader = false;

                innerTree.EnableIcons = true;

                innerTree.AutoScroll = true;
                menus = menus.OrderBy(m => m.ID).ToList();
                foreach (TreeNode node in GetTreeNodes(menus, menus[item.PanelID - 1]))
                {
                    innerTree.Nodes.Add(node);
                }

                accordionPane.Items.Add(innerTree);


            }
            ViewBag.accordionMenu = accordionMenu;

            ViewBag.UserName = GetIdentityName();
            ViewBag.OnlineUserCount = GetOnlineCount().ToString();
            ViewBag.ProductVersion = GetProductVersion();
            ViewBag.ConfigTitle = ConfigHelper.Title;

            ViewBag.SystemHelpItems = GetSystemHelpItems().ToArray();
        }
        #endregion

        #region 帮助菜单
        // 帮助菜单
        private List<MenuItem> GetSystemHelpItems()
        {
            List<MenuItem> items = new List<MenuItem>();

            JArray ja = JArray.Parse(ConfigHelper.HelpList);
            foreach (JObject jo in ja)
            {
                string text = jo.Value<string>("Text");
                Icon icon = IconHelper.String2Icon(jo.Value<string>("Icon"), true);
                string id = jo.Value<string>("ID");
                string url = jo.Value<string>("URL");

                if (!String.IsNullOrEmpty(text) && !String.IsNullOrEmpty(id) && !String.IsNullOrEmpty(url))
                {
                    MenuButton menuItem = new MenuButton();
                    menuItem.Text = text;
                    menuItem.Icon = icon;
                    menuItem.OnClientClick = String.Format("addExampleTab('{0}','{1}','{2}')", id, Url.Content(url), text);

                    items.Add(menuItem);
                    //CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, text, text);
                }
            }

            return items;
        }

        #endregion
        #region ResolveUserMenuList

        // 获取用户可用的菜单列表
        private List<EmptyProject.Models.Menu> ResolveUserMenuList()
        {
            // 当前登陆用户的权限列表
            List<string> rolePowerNames = GetRolePowerNames();
            // 当前用户所属角色可用的菜单列表
            List<EmptyProject.Models.Menu> menus = new List<EmptyProject.Models.Menu>();
            foreach (var menu in db.Menus.Include(m => m.ViewPower).OrderBy(m => m.SortIndex))
            {
                // 如果此菜单不属于任何模块，或者此用户所属角色拥有对此模块的权限
                if (menu.ViewPower == null || rolePowerNames.Contains(menu.ViewPower.Name))
                {
                    menus.Add(menu);
                }
            }

            return menus;
        }


        #endregion
        #region GetTreeNodes

        /// <summary>
        /// 创建树菜单
        /// </summary>
        /// <param name="menus"></param>
        /// <returns></returns>
        private IList<TreeNode> GetTreeNodes(List<EmptyProject.Models.Menu> menus, EmptyProject.Models.Menu parentMenu)
        {
            IList<TreeNode> nodes = new List<TreeNode>();

            // 生成树
            ResolveMenuTree(menus, parentMenu, nodes);

            // 展开第一个树节点
            if (nodes.Count > 0)
            {
                nodes[0].Expanded = true;
            }
            return nodes;
        }

        /// <summary>
        /// 生成菜单树
        /// </summary>
        /// <param name="menus"></param>
        /// <param name="parentMenuId"></param>
        /// <param name="nodes"></param>
        private int ResolveMenuTree(List<EmptyProject.Models.Menu> menus, EmptyProject.Models.Menu parentMenu, IList<TreeNode> nodes)
        {
            int count = 0;
            foreach (var menu in menus.Where(m => m.Parent == parentMenu))
            {
                TreeNode node = new TreeNode();
                nodes.Add(node);
                count++;

                node.Text = menu.Name;
                
                if (!String.IsNullOrEmpty(menu.NavigateUrl))
                {
                    node.NavigateUrl = Url.Content(menu.NavigateUrl);
                }

                if (menu.Children.Count == 0)
                {
                    node.Leaf = true;
                    node.IconUrl = menu.ImageUrl;
                    // 如果是叶子节点，但不是超链接，则是空目录，删除
                    if (String.IsNullOrEmpty(menu.NavigateUrl))
                    {
                        nodes.Remove(node);
                        count--;
                    }
                }
                else
                {
                    int childCount = ResolveMenuTree(menus, menu, node.Nodes);

                    // 如果是目录，但是计算的子节点数为0，可能目录里面的都是空目录，则要删除此父目录
                    if (childCount == 0 && String.IsNullOrEmpty(menu.NavigateUrl))
                    {
                        nodes.Remove(node);
                        count--;
                    }
                }

            }

            return count;
        }

        #endregion



        #region onSignOut_Click

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult onSignOut_Click()
        {
            FormsAuthentication.SignOut();

            // 清空Session，因为可能会在Session中保存数据
            Session.Abandon();
            
           string info = "在线时长：" +CommonBll.LoginDuration(User.Identity.Name, DateTime.Now);
            CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, info, "退出系统！");
            return RedirectToAction("Index", "Login");
        }


        #endregion


    }
}