﻿using System;
using System.Linq;
using System.Web.Mvc;
using FineUIMvc.EmptyProject.Models;
using System.Web.Security;
namespace FineUIMvc.EmptyProject.Controllers
{
    public class LoginController : BaseController
    {
         //登陆控制器
        // GET: Login
        public ActionResult Index()
        {
          
          
            LoadData();
            return View();
        }

        private void LoadData()
        {
            ViewBag.Window1Title = String.Format("系统登录（AppBoxMvc {0}）", GetProductVersion());

        }

        //用户点击登陆按钮
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult btnSubmit_Click(string tbxUserName, string tbxPassword)
        {
            string userName =  tbxUserName.Trim();
            string password =  tbxPassword.Trim();
            ViewBag.userName = userName;
            ViewBag.password = password;
            User user = db.Users.Where(u => u.Name == userName).FirstOrDefault();

            if (user != null)
            {
                if (PasswordUtil.ComparePasswords(user.Password, password))
                {
                    if (!user.Enabled)
                    {
                        Alert.Show("用户未启用，请联系管理员！");
                    }
                    else
                    {
                        // 登录成功
                        LoginSuccess(user);
                    }
                }
                else
                {
                    Alert.Show("用户名或密码错误！");
                }
            }
            else
            {
                Alert.Show("用户名或密码错误！");
            }

            return UIHelper.Result();
        }

        #region 用户和密码都正确时调用
        private void LoginSuccess(User user)
        {   //插入当前用户到在线表
            RegisterOnlineUser(user);
            // 用户所属的角色字符串，以逗号分隔
            string roleIDs = String.Empty;
            if (user.Roles != null)
            {
                roleIDs = String.Join(",", user.Roles.Select(r => r.ID).ToArray());
            }

            bool isPersistent = false;
            DateTime expiration = DateTime.Now.AddMinutes(120);
            CreateFormsAuthenticationTicket(user.Name, roleIDs, isPersistent, expiration);


            #region  日志记录
            // log4net.ILog log = log4net.LogManager.GetLogger(this.GetType().Name);
            // var ip = IpHelper.GetUserIp();

            // //创建客户端信息获取实体

            var browerInfo = System.Web.HttpContext.Current.Request.Browser.Platform.ToString();
            browerInfo = System.Web.HttpContext.Current.Request.Browser.Browser.ToString() + System.Web.HttpContext.Current.Request.Browser.Version.ToString();
            browerInfo = System.Web.HttpContext.Current.Request.Browser.Platform;
            // log.Info(new LogContent(ip, user.Name, browerInfo, "登陆成功"));

            CommonBll.WirteLogs(this.GetType().Name, user.Name, browerInfo, "登陆成功！");
            #endregion  日志记录

            // 重定向到登陆后首页
            Response.Redirect(FormsAuthentication.DefaultUrl);
        }
        #endregion
    }
}