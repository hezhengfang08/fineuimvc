﻿using System.Web.Mvc;

namespace FineUIMvc.EmptyProject.Controllers
{
    public class otherController : Controller
    {
        // GET: other
        public ActionResult Index()
        {
            return View();
        }
    }
}