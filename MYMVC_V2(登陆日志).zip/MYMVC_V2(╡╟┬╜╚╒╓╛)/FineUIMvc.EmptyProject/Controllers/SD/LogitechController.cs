﻿using System;
using System.Collections;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Data;
using System.Configuration;

namespace FineUIMvc.EmptyProject.Controllers.SD
{
    public class LogitechController : BaseController
    {
        public static DataTable dtHead = null;
        public static Hashtable hashTopTable;
        public static Hashtable hashTable;
        // GET: Logitech
        public ActionResult Index()
        {
           
            return View();
        }

        #region 生成商检资料

        public ActionResult Inspection()
        {
            string sp_name = "P_SD_INSP_LIST";
            string[] param = new string[1];
            param[0] = "Logitech";          
            BindGrid(sp_name, param);
            return View();

        }


        #region 绑定数据
        //private void BindGrid(string txtInspect)
        //{
        //    //表头

        //    int iPageIndex = 1;
        //    int iPageSize = 20;
        //    string WhereStr = " 1=1 ";

        //    string[] aryKey = new string[2];
        //    aryKey[0] = "Logitech";
        //    aryKey[1] = txtInspect;
        //    DataTable dtHead = QueryCommonTst.GetQueryResult("P_SD_INSP_LIST", "column", iPageIndex, iPageSize, WhereStr, aryKey);
        //    ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

        //    DataTable dt = QueryCommonTst.GetQueryResult("P_SD_INSP_LIST", "list", iPageIndex, iPageSize, WhereStr, aryKey);
        //    //表记录
        //    ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult("P_SD_INSP_LIST", "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);
        //    //表内容
        //    ViewBag.Grid1DataSource = dt;

        //}
        private void BindGrid(string sp_name,  string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";   
             
            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

        }
        #endregion

        #region 查询
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid1_ReBindGrid(JArray fields, string sp_name, int pageIndex, int pageSize, string txtParam)
        {
            var grid1 = UIHelper.Grid("Grid1");

            string[] aryKey = new string[4];
            aryKey[0] = "Logitech"; 
            aryKey[1] = txtParam;
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", pageIndex + 1, pageSize, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);

            // 1.设置总项数（数据库分页回发时，如果总记录数不变，可以不设置RecordCount）
            grid1.RecordCount(ViewBag.Grid1RecordCount);

            // 2. 设置每页显示项数（每页记录数改变时，要设置PageSize）
            grid1.PageSize(pageSize);


            grid1.DataSource(dt, fields);

            return UIHelper.Result();
        }
        #endregion 查询

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string sp_name, string txtParam)
        {
            string[] aryKey = new string[2];
            aryKey[0] = "Logitech";
            aryKey[1] = txtParam;  //OUPT;

            string strExcelName = sp_name +".xlsx";  //生成的EXCEL文件名
            CreateExportExcel createExportExcel = new CreateExportExcel();
            ////表头
            dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", aryKey);
            ////内容
            DataTable dtList = QueryCommonTst.GetQueryResult(sp_name, "export", 1, 99999, "1=1", aryKey);
           
            DataTable dthead_Del = dtHead.Clone();
            foreach (DataRow dr in dtHead.Rows)
            {
                if (dr["GROUP_NAME"].ToString().Trim() != "")
                {
                    DataRow dr_new = dthead_Del.NewRow();
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        dr_new[i] = dr[i].ToString().Trim();
                    }

                    dthead_Del.Rows.Add(dr_new);
                }
            }
            DataView dataView = dtHead.DefaultView;
            ////顶层栏位表头
            hashTopTable = new Hashtable();
            DataTable dataTableDistinct = dataView.ToTable(true, "GROUP_NAME");//注：其中ToTable（）的第一个参数为是否DISTINCT
            for (int m = 0; m < dataTableDistinct.Rows.Count; m++)
            {
                if (dataTableDistinct.Rows[m]["GROUP_NAME"].ToString().Trim() != "")
                {
                    hashTopTable.Add(m, dataTableDistinct.Rows[m]["GROUP_NAME"].ToString().Trim());
                }
            }

            ////用hashTable做个用于多表头的表
            ////用hashTable控制Grid的多栏位
            hashTable = new Hashtable();
            for (int n = 0; n < dtHead.Rows.Count; n++)
            {
                if (dtHead.Rows[n]["GROUP_NAME"].ToString().Trim() != "")
                {
                    hashTable.Add(dtHead.Rows[n]["COLUMN_NAME"].ToString().Trim(), dtHead.Rows[n]["GROUP_NAME"].ToString().Trim());
                }
            }

            string result = createExportExcel.ExportTwoHeadRowsExcel(dtList, dthead_Del, hashTopTable, hashTable, strExcelName);
            string filePath = ConfigurationManager.AppSettings["UploadFilePath"].ToString();
            //string ipAddress = ConfigurationManager.AppSettings["UrlAddress"].ToString();
            //return File(filePath + "\\" + strExcelName, "application/excel", strExcelName);
            string fileName = filePath + "\\" + strExcelName;
            //直接打开
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();
        }



        #endregion
        #endregion 生成商检资料
        public ActionResult Booking()
        {
            string sp_name = "P_SD_BOOK_LIST";
            string[] param = new string[1];
            param[0] = "Logitech";
            BindGrid(sp_name, param);
            return View();

        }
        #region BOOKING 资料

        #endregion
    }
}