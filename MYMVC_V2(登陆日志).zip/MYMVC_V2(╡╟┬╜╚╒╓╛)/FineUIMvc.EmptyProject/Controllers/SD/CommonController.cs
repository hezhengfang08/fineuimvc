﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.Models;
using FineUIMvc.EmptyProject.DAL;
using Utility;


namespace FineUIMvc.EmptyProject.Controllers.SD
{
    public class CommonController : BaseController
    {
        // GET: Common
        public ActionResult ModelInfo()
        {
            //绑定数据
            BindGrid(null, null);
            return View();
        }

        #region 修改机型
        private DataRow FindRowByID(DataTable table, string rowId)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row["KEYID"].ToString() == rowId)
                {
                    return row;
                }
            }
            return null;
        }
        public ActionResult UpdateModel(string KEYID)
        {
                    DataTable dt = GetDataTable("list");
                    Model model = DataTOModel<Model>.ConvertToModel(dt).Where(m => m.KEYID == KEYID.ToString()).FirstOrDefault();
                    if (model == null)
                    {
                        return Content("无效参数！");
                    }
                    return View(model);
        }
        #endregion

        #region 新增机型
        public ActionResult NewModel()
        {
            return View();
        }
        #endregion

        #region 导入功能
        
       public ActionResult LeadModel()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult fileExcel_FileSelected(HttpPostedFileBase fileExcel, FormCollection values)
        {
            if (fileExcel != null)
            {
                string fileName = fileExcel.FileName;

                if (!ValidateFileType(fileName))
                {
                    // 清空文件上传组件
                    UIHelper.FileUpload("fileExcel").Reset();

                    ShowNotify("无效的文件类型！");
                }
                else
                {
                    fileName = fileName.Replace(":", "_").Replace(" ", "_").Replace("\\", "_").Replace("/", "_");
                    fileName = DateTime.Now.Ticks.ToString() + "_" + fileName;

                    fileExcel.SaveAs(Server.MapPath("~/upload/" + fileName));

                    UIHelper.FileUpload("fileExcel").Text("~/upload/" + fileName);

                    //// 清空文件上传组件（上传后要记着清空，否则点击提交表单时会再次上传！！）
                    //UIHelper.FileUpload("fileExcel").Reset();
                }
            }

            return UIHelper.Result();
        }

    [HttpPost]
    [ValidateAntiForgeryToken]
   public ActionResult btnSubmit_Click(FormCollection values)
   {
            //var filePhoto = UIHelper.FileUpload("fileExcel");

            var tbxFileName = Server.MapPath( values["fileExcel"]);

            DataTable newTable = OperateExcel.ExcelImportToDataTable(tbxFileName);

            //sql串
            List<string> sqlList = new List<string>();

            foreach (DataRow newRow in newTable.Rows)
            {
                string cust_Name = GetCustName(newRow["客户编号"].ToString());
                string sql2 = "select * from ERPDB.T_SD_MODEL where PARTNO = '" + newRow["品号"].ToString() + "'";
                DataTable dt2 = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql2);
                if (dt2.Rows.Count == 0)
                {
                    string sqlstr = " INSERT INTO T_SD_MODEL(PARTNO,CUST_PARTNO,MODEL_CODE,MODEL_DESC,CUST_NAME,CUST_CODE,MODEL_VERSION) VALUES('" + newRow["品号"].ToString() + "','" + newRow["客户料件编号"].ToString() + "','" + newRow["机型代码"].ToString() + "','" + newRow["Description"].ToString() + "','" + cust_Name + "','" + newRow["客户编号"].ToString() + "','" + newRow["机型版本号"].ToString() + "')";
                    sqlList.Add(sqlstr);
                }
                else
                {
                    string sqlstr = " UPDATE T_SD_MODEL set CUST_PARTNO ='" + newRow["客户料件编号"].ToString() + "',MODEL_CODE ='" + newRow["机型代码"].ToString() + "',MODEL_DESC = '" + newRow["Description"].ToString() + "',CUST_NAME = '" + cust_Name + "',CUST_CODE = '" + newRow["客户编号"].ToString() + "',MODEL_VERSION = '" + newRow["机型版本号"].ToString() + "' where PARTNO ='" + newRow["品号"].ToString() + "'";
                    sqlList.Add(sqlstr);
                }


            }
            #region 执行结果
            try
            {
                DBConnOracle.ExcuteNoQuerySS(AppConfiguration.ERPDBToptst, sqlList);

                //BindGrid();
                //Alert.Show("数据保存成功！（表格数据已重新绑定）");
            }
            catch (Exception err)
            {
                Alert.Show(err.Message);
            }
            #endregion

            ActiveWindow.HidePostBack();


            ShowNotify("数据保存成功！（表格数据已重新绑定）");

            return UIHelper.Result();

        }


        
        #endregion

        #region 删除数据 选择的列
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid1_DeleteRows(JArray Grid1_fields, JArray selectedRows)
        {
            DataTable source = GetDataTable("list");

            foreach (string rowId in selectedRows)
            {
                DeleteRowByID(source, rowId);
            }

            UIHelper.Grid("Grid1").DataSource(source, Grid1_fields);

            ShowNotify("删除数据成功!（表格数据已重新绑定）");

            return UIHelper.Result();
        }


        private void DeleteRowByID(DataTable table, string rowID)
        {
            DataRow found = FindRowByID(table, rowID);
            if (found != null)
            {


                string strsql = "delete from T_SD_MODEL where KEYID='" + found["KEYID"] + "'";

                DBConnOracle.ExcuteNoQuery(AppConfiguration.ERPDBToptst, strsql);
                //前端
                table.Rows.Remove(found);
            }
        }

        #endregion

        #region 导出excel
       
    public ActionResult btnExport_Click(JArray fields, string txtCust, string txtModel, string txtPartno)
    {
            DataTable dt = GetDataTable("export", txtCust, txtModel, txtPartno);
            var fileName = Server.MapPath("~/Files/PartModel.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion

        #region  修改按钮
        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckPower(Name = "CoreUserNew")]
        public ActionResult btnUpdateClose_Click([Bind(Include = "PARTNO,PART_NAME,PART_SPEC,CUST_PARTNO,MODEL_CODE,MODEL_DESC,CUST_CODE,MODEL_VERSION")]Model model)
        {
           
            if (ModelState.IsValid)
            {
                string cust_Name = GetCustName(model.CUST_CODE);


                string sqlstr = " UPDATE T_SD_MODEL set CUST_PARTNO ='" + model.CUST_PARTNO + "',MODEL_CODE ='" + model.MODEL_CODE + "',MODEL_DESC = '" + model.MODEL_DESC + "',CUST_NAME = '" + cust_Name + "',CUST_CODE = '" + model.CUST_CODE + "',MODEL_VERSION = '" + model.MODEL_VERSION + "' where PARTNO ='" + model.PARTNO+"'";
                DBConnOracle.ExcuteNoQuery(AppConfiguration.ERPDBToptst, sqlstr);
                // 关闭本窗体（触发窗体的关闭事件）
                ActiveWindow.HidePostBack();
            }

            return UIHelper.Result();
        }

        private string GetCustName(string custCode)
        {
            string CUST_NAME = "";
            if (custCode == "Logitech") { CUST_NAME = "罗技"; }
            if (custCode == "Harman") { CUST_NAME = "哈曼"; }
            if (custCode == "Philips") { CUST_NAME = "飞利浦"; }
            return CUST_NAME;
        }
        #endregion
        #region  保存按钮
        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckPower(Name = "CoreUserNew")]
        public ActionResult btnSaveClose_Click([Bind(Include = "PARTNO,PART_NAME,PART_SPEC,CUST_PARTNO,MODEL_CODE,MODEL_DESC,,CUST_CODE,MODEL_VERSION, NWKG, GWKG, CBM")]Model model)
        {
            if (ModelState.IsValid)
            {     
                string sql2 = "select * from ERPDB.T_SD_MODEL where PARTNO = '" + model.PARTNO.ToString() + "'";
                DataTable dt = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql2);
                if (dt.Rows.Count > 0)
                {
                    Alert.Show(model.PARTNO + " 已经存在！");
                    return UIHelper.Result();
                }
                //sql语句集合
                List<string> sqlList = new List<string>();

                string cust_Name = GetCustName(model.CUST_CODE);
                //三个表的语句在一个事物中处理 
                //1
                string sqlstr = " INSERT INTO T_SD_MODEL(PARTNO,CUST_PARTNO,MODEL_CODE,MODEL_DESC,CUST_NAME,CUST_CODE,MODEL_VERSION, NWKG, GWKG, CBM ) VALUES('" + model.PARTNO + "','" + model.CUST_PARTNO + "','" + model.MODEL_CODE + "','" + model.MODEL_DESC + "','" + cust_Name + "','" + model.CUST_CODE + "','" + model.MODEL_VERSION + "'," + model.NWKG + "," + model.GWKG + "," + model.CBM+ ")";
                sqlList.Add(sqlstr);
                //2
                sqlstr = "update imaa_t set imaaud002 = '" + model.MODEL_VERSION + "', imaaud001 = '" + model.MODEL_CODE + "', imaa016 = '" + model.NWKG + "', imaa017 = '" + model.GWKG + "', imaa025 = '" + model.CBM + "', imaamodid = '" + User.Identity.Name + "', imaamoddt = sysdate where imaaent = 100 and imaa001 = '" + model.PARTNO + "'" ;
                sqlList.Add(sqlstr);
                //3
                sqlstr = "MERGE INTO pmao_t P" +
                " USING(SELECT PARTNO, CUST_CODE, CUST_PARTNO FROM T_SD_MODEL) S" +
                " ON(P.pmaoent = 100 and P.pmao002 = S.PARTNO) "+
                " WHEN MATCHED THEN" +
                " UPDATE SET P.pmao001 = S.CUST_CODE, P.pmao004 = S.CUST_PARTNO, P.pmaomodid = '" + User.Identity.Name + "', P.pmaomoddt = sysdate "+
                " WHEN NOT MATCHED THEN " +
                " INSERT(pmaoent, pmao000, pmao001, pmao002, pmao003, pmao004, pmaocrtid, pmaocrtdp, pmaocrtdt)" +
                "values(100, '2', S.CUST_CODE, S.PARTNO, ' ', S.CUST_PARTNO, '"+User.Identity.Name + "', get_value('user_dept', '"+ User.Identity.Name +"') , sysdate )" ;
                sqlList.Add(sqlstr);
                DBConnOracle.ExcuteNoQuerySS(AppConfiguration.ERPDBToptst, sqlList);

                // 关闭本窗体（触发窗体的关闭事件）
                ActiveWindow.HidePostBack();
            }

            return UIHelper.Result();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ModelInfo_DoPostBack(JArray Grid1_fields)
        {
            GetSourceData();
            UIHelper.Grid("Grid1").DataSource(ViewBag.Grid1DataSource, Grid1_fields);

            return UIHelper.Result();
        }

        #endregion
        #region 绑定数据
        private void BindGrid(string txtItemname, string txtItemSpec)
        {
            //表头
            DataTable dtHead = QueryCommonTst.GetQueryResult("P_SD_MODEL_LIST", "column", null);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);
            GetSourceData();


        }
        #endregion

        #region 查询数据
        public ActionResult btnSearch_Click(JArray fields, string txtCust, string txtModel, string txtPartno)
        {
            var grid1 = UIHelper.Grid("Grid1");
            GetSourceData(txtCust, txtModel, txtPartno);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);

            return UIHelper.Result();
        }
        #endregion 
        #region 取数据
        private void GetSourceData(string txtCust = "", string txtModel = "", string txtPartno = "")
        {
            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            string[] aryKey = new string[4];
            aryKey[0] = txtCust;
            aryKey[1] = txtModel;
            aryKey[2] = txtPartno;
            DataTable dt = QueryCommonTst.GetQueryResult("P_SD_MODEL_LIST", "list", iPageIndex, iPageSize, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult("P_SD_MODEL_LIST", "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

        }
        #endregion
        #region 取结果集
        private DataTable GetDataTable(string p_type, string txtCust = "", string txtModel = "", string txtPartno = "")
        {
            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            string[] aryKey = new string[4];
            aryKey[0] = txtCust;
            aryKey[1] = txtModel;
            aryKey[2] = txtPartno;
            DataTable dt = QueryCommonTst.GetQueryResult("P_SD_MODEL_LIST", p_type, iPageIndex, iPageSize, WhereStr, aryKey);
            return dt;
        }
        #endregion
    }
}