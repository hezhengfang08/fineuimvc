﻿using System;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Data;
using System.Collections;

namespace FineUIMvc.EmptyProject.Controllers.SALES
{
    public class Sales1Controller : BaseController
    {
        #region 全局变量
        public static Hashtable hashTopTable;
        public static Hashtable hashTable;
        public static string txtSite1 = null;
        public static string txtBegin1 = null;
        public static string txtEnd1 = null;
        public static string sp_name1 = "P_MA_SASSD_LIST";
 
        #endregion 全局变量
        // GET: Sales1
        public ActionResult MA_SASSD()
        {
           
            BindDDL_List();
            string[] param = new string[3];
            param[0] = txtSite1;
            param[1] = txtBegin1;
            param[2] = txtEnd1;
            BindGrid1(sp_name1, param);
            ViewBag.Selected = txtSite1;
            return View();
        }

        #region 下拉框
        private void BindDDL_List(string[] key = null)
        {
            DataTable dt = QueryCommonTst.GetQueryResult("P_DROPDOWN_LIST", "site", key);

            ViewBag.ddl_SiteDataSource = dt;

        }
        #endregion 下拉框

        #region 数据绑定
        private void BindGrid1(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //记录数
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);

            //表内容
            ViewBag.Grid1DataSource = dt;

            //顶层栏位表头
            hashTopTable = new Hashtable();
            hashTopTable.Add("A", "年月");
            hashTopTable.Add("B", "总计");
            for (int i = 4; i < dt.Columns.Count; i++)
            {
                hashTopTable.Add("C" + i, dt.Columns[i].ColumnName.Split('_')[0]);
                i = i + 3;
            }

            //用hashTable做个用于多表头的表
            //用hashTable控制Grid的多栏位
            hashTable = new Hashtable();
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].ColumnName.Contains("YEARMONTH"))
                { hashTable.Add(dt.Columns[i].ColumnName, "年月"); }
                if (dt.Columns[i].ColumnName.Contains("数量总计"))
                { hashTable.Add(dt.Columns[i].ColumnName, "总计"); }
                if (dt.Columns[i].ColumnName.Contains("金额总计"))
                { hashTable.Add(dt.Columns[i].ColumnName, "总计"); }
                if (dt.Columns[i].ColumnName.Contains("总计达成率"))
                { hashTable.Add(dt.Columns[i].ColumnName, "总计"); }

                if (dt.Columns[i].ColumnName.Contains("数量") & !dt.Columns[i].ColumnName.Contains("总计"))
                { hashTable.Add(dt.Columns[i].ColumnName, dt.Columns[i].ColumnName.Split('_')[0]); }
                if (dt.Columns[i].ColumnName.Contains("金额") & !dt.Columns[i].ColumnName.Contains("总计"))
                { hashTable.Add(dt.Columns[i].ColumnName, dt.Columns[i].ColumnName.Split('_')[0]); }
                if (dt.Columns[i].ColumnName.Contains("达成率") & !dt.Columns[i].ColumnName.Contains("总计"))
                { hashTable.Add(dt.Columns[i].ColumnName, dt.Columns[i].ColumnName.Split('_')[0]); }
            }
            //hashTable.Add("Ordered Qty", "主要信息");
            //表头
            //dtHead = QueryCommon.GetQueryResult("P_SD_OMS_LIST", "column", null);

            //设置冻结列
            string[] lockgrpcols = { "年月" };

            //DataTable dtHead_1 = QueryCommon.GetQueryResult("P_MA_SASSD_LIST", "column", null);
            //ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead_1);
            ViewBag.Grid1Columns = GridCommon.GridTwoHeadColumnsWithNoProceColumns(hashTopTable, hashTable, dt, lockgrpcols);

        }
        #endregion 数据绑定

        #region 查询数据
        public ActionResult Grid1_ReBindGrid(JArray fields, string sp_name, int pageIndex, int pageSize, string txtSite, FormCollection values)
        {
            sp_name1 = sp_name;
            txtSite1 = txtSite;
            txtBegin1 = values["DatePicker1"];
            txtEnd1 = values["DatePicker2"];

            Response.Redirect("~/Sales1/MA_SASSD");
            return UIHelper.Result();
        }
        #endregion

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string sp_name, string txtSite, FormCollection values)
        {

            string txtBegin = values["DatePicker1"];
            string txtEnd = values["DatePicker2"];
            string[] aryKey = new string[3];
            aryKey[0] = txtSite;
            aryKey[1] = txtBegin;
            aryKey[2] = txtEnd;
            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "export", 1, 99999, "1=1", aryKey);
            var fileName = Server.MapPath("~/Files/MA_SASAD.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion
    }
}