﻿using System;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.DAL;
using Utility;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.SALES
{
    public class Sales2Controller : BaseController
    {
        // GET: Sales2
        public ActionResult MA_SASSG()
        {
            string sp_name1 = "P_MA_SASSG_LIST";
            BindDDL_List();
            string[] param = new string[3];
            param[0] = "S10";
            param[1] = "2017-06-01";
            param[2] = "2017-12-01";
            BindGrid(sp_name1, param);
            return View();
        }


        #region 下拉框
        private void BindDDL_List(string[] key = null)
        {
            DataTable dt = QueryCommonTst.GetQueryResult("P_DROPDOWN_LIST", "site", key);

            ViewBag.ddl_SiteDataSource = dt;

        }
        #endregion 下拉框
        #region 绑定数据
        private void BindGrid(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, param).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

        }
        #endregion 绑定数据

        #region 查询数据
        public ActionResult Grid1_ReBindGrid(JArray fields, string sp_name, int pageIndex, int pageSize, string txtSite, FormCollection values)
        {
            var grid1 = UIHelper.Grid("Grid1");
            string txtBegin = values["DatePicker1"];
            string txtEnd = values["DatePicker2"];
            string[] aryKey = new string[3];
            aryKey[0] = txtSite;
            aryKey[1] = txtBegin;
            aryKey[2] = txtEnd;
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", pageIndex + 1, pageSize, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommonTst.GetQueryResult(sp_name, "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);

            // 1.设置总项数（数据库分页回发时，如果总记录数不变，可以不设置RecordCount）
            grid1.RecordCount(ViewBag.Grid1RecordCount);

            // 2. 设置每页显示项数（每页记录数改变时，要设置PageSize）
            grid1.PageSize(pageSize);


            grid1.DataSource(dt, fields);

            return UIHelper.Result();
        }
        #endregion

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string sp_name, string txtSite, FormCollection values)
        {

            string txtBegin = values["DatePicker1"];
            string txtEnd = values["DatePicker2"];
            string[] aryKey = new string[3];
            aryKey[0] = txtSite;
            aryKey[1] = txtBegin;
            aryKey[2] = txtEnd;
            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "export", 1, 99999, "1=1", aryKey);
            var fileName = Server.MapPath("~/Files/MA_SASAD.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion
    }
}