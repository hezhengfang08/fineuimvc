﻿using System.Web.Mvc;
using FineUIMvc.EmptyProject.DAL;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.SALES
{
    public class SalesTestController : BaseController
    {
        // GET: SalesTest
        public ActionResult Test()
        {

            string sp_name = "P_MA_INVMD_LIST";
           
            string[] param = new string[3];
            param[0] = "S10";
            param[1] = "ALL";
            param[2] = "N";
            BindGrid(sp_name, param);
            return View();
           
        }

        #region 绑定数据
        private void BindGrid(string sp_name, string[] param)
        {
            //表头

            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            DataTable dtHead = QueryCommonTst.GetQueryResult(sp_name, "column", iPageIndex, iPageSize, WhereStr, param);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);

            DataTable dt = QueryCommonTst.GetQueryResult(sp_name, "list", iPageIndex, iPageSize, WhereStr, param);
            //表记录  初始不加载  点击查询再加载
            ViewBag.Grid1RecordCount = 0;
            //表内容
            ViewBag.Grid1DataSource = null;

        }
        #endregion 绑定数据
    }
}