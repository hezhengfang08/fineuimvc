﻿using System;
using System.Web.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.Models;
using FineUIMvc.EmptyProject.DAL;
using Utility;
namespace FineUIMvc.EmptyProject.Controllers
{
    public class BaseDataController : BaseController
    {
        // GET: BaseData
        public ActionResult Index()
        {  
            return View();
        }


        [CheckPower(Name = "CoreOnlineView")]
        public ActionResult materlist(FineUIMvc.Grid Grid1)
        {   //绑定数据
            BindGrid(null,null);
            return View();
        }

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string txtItemname, string txtItemSpec)
        {
            string WhereStr = "1=1";
            string[] aryKey = new string[4];
            aryKey[0] = txtItemname;
            aryKey[1] = txtItemSpec;


            DataTable dt = QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "export", 1, 99999, WhereStr, aryKey);
            var fileName = Server.MapPath("~/Files/ERPITEM.xlsx");
            OperateExcel.CreateExcel( dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();
            
        }
        #endregion
        public ActionResult btnSearch_Click(JArray fields, string txtItemname, string txtItemSpec)
        {
            var grid1 = UIHelper.Grid("Grid1");
            BindGrid(txtItemname, txtItemSpec);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);

            return  UIHelper.Result();
        }

        private void BindGrid(string txtItemname, string txtItemSpec)
        {
            //表头
            DataTable dtHead = QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "column", null);
            ViewBag.Grid1Columns = GridCommon.GridHeadColumns(dtHead);
            int iPageIndex = 1;
            int iPageSize = 20;
            string WhereStr = " 1=1 ";

            string[] aryKey = new string[4];
            aryKey[0] = txtItemname;
            aryKey[1] = txtItemSpec;

            DataTable dt = QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "list", iPageIndex, iPageSize, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);
            //表内容
            ViewBag.Grid1DataSource = dt;

        }

        //分页排序
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid1_ReBindGrid(JArray fields, int pageIndex, int pageSize, string txtItemname, string txtItemSpec)
        {
            var grid1 = UIHelper.Grid("Grid1");

            string[] aryKey = new string[4];
            aryKey[0] = txtItemname;
            aryKey[1] = txtItemSpec;
            string WhereStr = " 1=1 ";

            DataTable dt = QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "list", pageIndex + 1, pageSize, WhereStr, aryKey);
            //表记录
            ViewBag.Grid1RecordCount = Convert.ToInt32(QueryCommon.GetQueryResult("WSP_ERPITEM_LIST", "count", 1, 99999, WhereStr, aryKey).Rows[0][0]);

            // 1.设置总项数（数据库分页回发时，如果总记录数不变，可以不设置RecordCount）
            grid1.RecordCount(ViewBag.Grid1RecordCount);

            // 2. 设置每页显示项数（每页记录数改变时，要设置PageSize）
            grid1.PageSize(pageSize);

           
            grid1.DataSource(dt, fields);

            return UIHelper.Result();
        }
    }
}