﻿using System;
using System.Web.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;
using Utility;

namespace FineUIMvc.EmptyProject.Controllers.Base
{
    public class LogDetailController : BaseController
    {
        // GET: LogDetail
        public ActionResult Index()
        {    //绑定数据
            BindGrid();
            return View();
        }
        #region BindGrid
        private void BindGrid()
        {
           
            ViewBag.Grid1DataSource = GetSourceData();
            ViewBag.Grid1RecordCount = Convert.ToInt32(GetSourceCount().Rows[0][0]);
        }

        #endregion
        #region 查询数据
        public ActionResult Grid1_ReBindGrid(JArray fields, string txtLogText)
        {
            var grid1 = UIHelper.Grid("Grid1");
            ViewBag.Grid1DataSource = GetSourceData(txtLogText);
            ViewBag.Grid1RecordCount = Convert.ToInt32(GetSourceCount(txtLogText).Rows[0][0]);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);
            grid1.RecordCount(ViewBag.Grid1RecordCount);
            return UIHelper.Result();
        }
        #endregion
        #region 取数据
        private DataTable GetSourceData(string txtLogText = "")
        {
            txtLogText = "%" + txtLogText + "%";
            string sql = " SELECT LogDate, LogThread, LogLevel, LogLogger, LogMessage, LogActionClick, UserName, UserIP FROM LogDetails where LogMessage like '" + txtLogText + "'";

            sql += " order by LogDate desc, LogMessage";
            DataTable dt = DBConnSql.GetDataTable(AppConfiguration.SqlDefault, sql);
            return dt;

        }
        #endregion

        #region 取记录总数
        private DataTable GetSourceCount(string txtLogText = "")
        {
            txtLogText = "%" + txtLogText + "%";
            string sql = " SELECT COUNT(*) as cnt FROM LogDetails where LogMessage like '" + txtLogText + "'";
           
            DataTable dt = DBConnSql.GetDataTable(AppConfiguration.SqlDefault, sql);
            return dt;

        }
        #endregion

        #region 导出excel
        public ActionResult Grid1_BtnExport(JArray fields, string txtLogText)
        {

            DataTable dt = ViewBag.Grid1DataSource = GetSourceData(txtLogText);


            var fileName = Server.MapPath("~/Files/Login.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion
    }
}