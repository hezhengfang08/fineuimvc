﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;
using FineUIMvc.EmptyProject.Models;
using Utility;

namespace FineUIMvc.EmptyProject.Controllers
{
    public class HeadManageController : BaseController
    {
        // GET: HeadManage

        [CheckPower(Name = "CoreHeaderView")]
        public ActionResult Index()
        {   //绑定数据
            Menu_LoadData();
            BindGrid();
            return View();
        }
        #region 按钮权限
        private void Menu_LoadData()
        {
            ViewBag.CoreHeaderNew = CheckPower("CoreHeaderNew");
            ViewBag.CoreHeaderSave = CheckPower("CoreHeaderSave");
            ViewBag.CoreHeaderDelete = CheckPower("CoreHeaderDelete");

        }

        #endregion 按钮权限

        #region BindGrid
        private void BindGrid()
        {
            ViewBag.DropDownList1DataSource = GetDDLSouce();
            ViewBag.Grid1DataSource = GetSourceData();
           
        }

        #endregion

        #region test
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ddlProgrm_SelectedIndexChanged( string ddlProgrm, JArray fields )
        {
            var grid1 = UIHelper.Grid("Grid1");
            ViewBag.Grid1DataSource = GetSourceData(ddlProgrm);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);
           
            return UIHelper.Result();

         
        }

        


        #endregion test

        #region 查询数据
        public ActionResult btnSearch_Click(JArray fields, string txtProgram)
        {
            var grid1 = UIHelper.Grid("Grid1");
            ViewBag.Grid1DataSource=GetSourceData(txtProgram);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);
            CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, "用户进入表头管理", "点击了查询按钮");
            return UIHelper.Result();
        }
        #endregion

        //#region 下拉框改变事件
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult ddlProgrm_SelectedIndexChanged(JArray fields)
        //{

        //    var grid1 = UIHelper.Grid("Grid1");
        //    //ViewBag.Grid1DataSource = GetSourceData(ddlProgrm);
        //    grid1.DataSource(ViewBag.Grid1DataSource, fields);
        //    return UIHelper.Result();
        //}
        //#endregion 

        #region 保存数据
        //int i = 10;
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult btnSubmit_Click(JArray fields, JArray mergedData)
        {
            // 复制原始表格的结构
            DataTable newTable = GetSourceData().Clone();
            DataRow newRow;
            //sql串
            List<string> sqlList = new List<string>();
           
                foreach (JObject mergedRow in mergedData)
                {
                    string status = mergedRow.Value<string>("status");
                    int rowIndex = mergedRow.Value<int>("index");
                    JObject values = mergedRow.Value<JObject>("values");
                if (status == "newadded" || status == "modified")
                {
                    newRow = newTable.NewRow();
                    newRow["KEYID"] = values.Value<string>("KEYID");  // 将行标识符设置为行索引号，实际项目中这个应该是数据库中的自增长主键，无需设置
                    newRow["PROGRAM_ID"] = values.Value<string>("PROGRAM_ID");
                    newRow["COLUMN_NAME"] = values.Value<string>("COLUMN_NAME");
                    newRow["DATA_FIELD"] = values.Value<string>("DATA_FIELD");
                    newRow["DATA_TYPE"] = values.Value<string>("DATA_TYPE");
                   
                    var flag = values.Value<string>("DATA_FIELD");
                    if (flag.IndexOf("QTY") > 0)
                    {
                        newRow["COLUMN_WIDTH"] = "80";
                        newRow["DATA_FORMAT"] = "{0:N2}";
                        newRow["DATA_TYPE"] = "Decimal";
                    }
                    else if (flag.IndexOf("DATE") > 0)
                    {
                        newRow["COLUMN_WIDTH"] = "150";
                        newRow["DATA_FORMAT"] = "{0:yyyy-MM-dd}";
                        newRow["DATA_TYPE"] = "Date";
                    }

                    else if (flag.IndexOf("NAME") > 0 || flag.IndexOf("DESC") > 0 || flag.IndexOf("REMARK") > 0)
                    {
                        newRow["COLUMN_WIDTH"] = "200";
                        newRow["DATA_FORMAT"] = "{0}";
                        newRow["DATA_TYPE"] = "String";
                    }
                    else
                    {
                        newRow["COLUMN_WIDTH"] = "150";
                        newRow["DATA_FORMAT"] = "{0}";
                        newRow["DATA_TYPE"] = "String";
                    }
                    //newRow["COLUMN_ID"] = i.ToString();
                    //i += i;
                    newRow["COLUMN_ID"] = values.Value<int>("COLUMN_ID");
                    newRow["COLUMN_LOCK"] = values.Value<int>("COLUMN_LOCK");
                    newRow["COLUMN_HIDE"] = values.Value<int>("COLUMN_HIDE");
                    newRow["COLUMN_EXCEL"] = values.Value<int>("COLUMN_EXCEL");
                    newRow["COLUMN_KEY"] = values.Value<int>("COLUMN_KEY");
                    //newTable.Rows.Add(newRow);
                    //判断是否存在
                    //string sql2 = "select * from ERPDB.SYS_COLUMN where KEYID = '"+ newRow["KEYID"].ToString()+"'";
                    //DataTable dt = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql2);
                    // 在第一行新增一条数据
                   
                    if (status == "newadded")
                    {
                        string sql = @"insert into ERPDB.SYS_COLUMN(PROGRAM_ID, DATA_FIELD,DATA_TYPE,DATA_FORMAT,COLUMN_ID,COLUMN_NAME,COLUMN_WIDTH,COLUMN_LOCK,COLUMN_KEY,COLUMN_HIDE,COLUMN_EXCEL)" +
                        " values('" + newRow["PROGRAM_ID"].ToString() + "','" + newRow["DATA_FIELD"].ToString().Trim() + "','" + newRow["DATA_TYPE"].ToString() + "','" + newRow["DATA_FORMAT"].ToString() + "'," + newRow["COLUMN_ID"].ToString() + ",'" + newRow["COLUMN_NAME"].ToString().Trim() + "'" +
                        "," + newRow["COLUMN_WIDTH"].ToString() + "," + newRow["COLUMN_LOCK"].ToString() + "," + newRow["COLUMN_KEY"].ToString() + "," + newRow["COLUMN_HIDE"].ToString() + "," + newRow["COLUMN_EXCEL"].ToString() + ")";
                        CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, "用户进入表头管理", "新增了数据：" + newRow["PROGRAM_ID"].ToString()+"字段名："+ newRow["DATA_FIELD"].ToString());
                        sql = sql.Replace("False", "0").Replace("True", "1");
                        sqlList.Add(sql);
                      
                    }
                    else if (status == "modified")
                    {
                        string sql = "update ERPDB.SYS_COLUMN set PROGRAM_ID = '" + newRow["PROGRAM_ID"].ToString() + "', DATA_FIELD = '" + newRow["DATA_FIELD"].ToString().Trim() + "', DATA_TYPE = '" + newRow["DATA_TYPE"].ToString() + "', DATA_FORMAT = '" + newRow["DATA_FORMAT"].ToString() + "', COLUMN_ID =  " + newRow["COLUMN_ID"].ToString() + ", COLUMN_NAME = '" + newRow["COLUMN_NAME"].ToString().Trim() + "', COLUMN_WIDTH = "
                       + newRow["COLUMN_WIDTH"].ToString() + " , COLUMN_LOCK = " + newRow["COLUMN_LOCK"].ToString() + ",COLUMN_KEY = " + newRow["COLUMN_KEY"].ToString() + ", COLUMN_HIDE = " + newRow["COLUMN_HIDE"].ToString() + ", COLUMN_EXCEL = " + newRow["COLUMN_EXCEL"].ToString() + " where KEYID='" + newRow["KEYID"].ToString() + "'";
                        sql = sql.Replace("False", "0").Replace("True", "1");
                        CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, "用户进入表头管理", "更新了KEYID：" + newRow["KEYID"].ToString());
                        sqlList.Add(sql);
                    }
                }

            }
            #region 执行结果
            try
            {
                DBConnOracle.ExcuteNoQuerySS(AppConfiguration.ERPDBToptst, sqlList);
                
                //BindGrid();
                //Alert.Show("数据保存成功！（表格数据已重新绑定）");
            }
            catch (Exception err)
            {
                Alert.Show(err.Message);
            }
            #endregion

            UIHelper.Grid("Grid1").DataSource(GetSourceData(), fields);


            ShowNotify("数据保存成功！（表格数据已重新绑定）");

            return UIHelper.Result();

        }


        #endregion 保存数据

        
        #region 取数据
        private DataTable GetSourceData(string txtProgram ="")
        {
            txtProgram = txtProgram + "%";
            string sql = " select * from ERPDB.SYS_COLUMN where 1=1 and PROGRAM_ID like '" + txtProgram + "'"; 

                sql += " order by PROGRAM_ID desc,COLUMN_ID";
                DataTable dt = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql);

                 return dt;

        }
        #endregion

        #region 取下拉框
        private DataTable GetDDLSouce()
        {

            string sql = " select distinct PROGRAM_NAME  ddltxt, PROGRAM_ID ddlvalue from ERPDB.SYS_PROGRAM ";
            sql += " order by PROGRAM_ID desc";
            DataTable dt = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql);
            return dt;

        }
        #endregion

        #region 删除数据 选择的列
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Grid1_DeleteRows(JArray Grid1_fields, JArray selectedRows)
        {
            DataTable source = GetSourceData();

            foreach (string rowId in selectedRows)
            {
                DeleteRowByID(source, rowId);
                CommonBll.WirteLogs(this.GetType().Name, User.Identity.Name, "用户进入表头管理", "删除了KEYID：" + rowId);
            }
           
            UIHelper.Grid("Grid1").DataSource(source, Grid1_fields);

            ShowNotify("删除数据成功!（表格数据已重新绑定）");

            return UIHelper.Result();
        }


        private void DeleteRowByID(DataTable table, string rowID)
        {
            DataRow found = FindRowByID(table, rowID);
            if (found != null)
            {
                

               string strsql = "delete from SYS_COLUMN where KEYID='" + found["KEYID"] + "'";

                DBConnOracle.ExcuteNoQuery(AppConfiguration.ERPDBToptst, strsql);
                //前端
                table.Rows.Remove(found);
            }
        }
        private DataRow FindRowByID(DataTable table, string rowId)
        {
            foreach (DataRow row in table.Rows)
            {
                if (row["KEYID"].ToString() == rowId)
                {
                    return row;
                }
            }
            return null;
        }
        #endregion

        #region 触发事件

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TextBox1_TextChanged(string text)
        {
            UIHelper.Label("labResult1").Text("文本框一：" + text);
            UIHelper.TextBox("txtDATA_TYPE").Text("文本框一：" + text);
            return UIHelper.Result();
        }


        #endregion 触发事件

        #region 导出excel
        public ActionResult btnExport_Click(JArray fields, string txtProgram)
        {

            DataTable dt = ViewBag.Grid1DataSource = GetSourceData(txtProgram);
            
           
            var fileName = Server.MapPath("~/Files/Header.xlsx");
            OperateExcel.CreateExcel(dt, fileName);
            //第三种:使用FilePathResult
            //服务器上首先必须要有这个Excel文件,然会通过Server.MapPath获取路径返回.
            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook wkb = app.Workbooks.Add(fileName);
            //打开已经存在的excel,
            //而通过gdal打开已经存在的shp,方法为
            // OSGeo.GDAL.Gdal.AllRegister();
            // OSGeo.GDAL.Dataset dataSet = OSGeo.GDAL.Gdal.Open(@"E:\Work\DemoBase_091111\GDALTEST\testshapefile\point_out.shp", Access.GA_ReadOnly);   
            //二者是差不多的，一个用add方法，一个用open方法，都得到了可以进行下一步操作的文件，技术具有相同性
            app.Visible = true;
            return UIHelper.Result();

        }
        #endregion

    }
}