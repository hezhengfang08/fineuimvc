﻿using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using Utility;
using System.Data;

namespace FineUIMvc.EmptyProject.Controllers.Base
{
    public class ProgramController : BaseController
    {
        // GET: Program
        public ActionResult Index()
        { //绑定数据
            BindGrid();
            return View();
        }
        #region 查询

        private void BindGrid()
        {
            DataTable dt = GetSourceData();
            ViewBag.Grid1DataSource =dt ;

           
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult btnSearch_Click(JArray fields,  string txtProgramID, string txtProgramName)
        {
            var grid1 = UIHelper.Grid("Grid1");
            ViewBag.Grid1DataSource = GetSourceData(txtProgramID, txtProgramName);
            grid1.DataSource(ViewBag.Grid1DataSource, fields);

            return UIHelper.Result();

        }
        #endregion 查询
        #region 取数据
        private DataTable GetSourceData(string txtProgramID = "", string txtProgramName = "")
        {
            txtProgramID = "%"+ txtProgramID + "%";
            txtProgramName = "%" + txtProgramName + "%";
            string sql = " select * from ERPDB.SYS_PROGRAM where 1=1 and PROGRAM_ID like '" + txtProgramID + "' and PROGRAM_NAME like '" +txtProgramName+ "'";

            sql += " order by PROGRAM_NAME";
            DataTable dt = DBConnOracle.GetDataTable(AppConfiguration.ERPDBToptst, sql);

            return dt;

        }
        #endregion
    }
}