﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utility
{
    public class BaseClass
    {

        #region 返回json数据
        /// <summary>
        /// 操作成功的提示
        /// </summary>
        /// <returns>json</returns>
        public string Success()
        {
            return "{\"statusCode\":\"200\", \"message\":\"操作成功！\"}";
        }
        /// <summary>
        /// 操作成功的提示
        /// </summary>
        /// <param name="str">提示信息</param>
        /// <returns>json</returns>
        public string Success(string str)
        {
            return "{\"statusCode\":\"200\", \"message\":\"" + str + "\"}";
        }

        /// <summary>
        /// 操作失败返回的json
        /// </summary>
        /// <returns>json</returns>
        public string Failure()
        {
            return "{\"statusCode\":\"300\", \"message\":\"操作失败！\"}";
        }
        /// <summary>
        /// 操作失败返回的json
        /// </summary>
        /// <param name="str">提示信息</param>
        /// <returns>json信息</returns>
        public string Failure(string str)
        {
            return "{\"statusCode\":\"300\", \"message\":\"操作失败：" + str + "\"}";
        }

        /// <summary>
        /// 自定义
        /// </summary>
        /// <returns></returns>
        public string DefineAction()
        {
            return "{\"statusCode\":\"201\", \"message\":\"自定义返回值201\"}";
        }
        /// <summary>
        /// 自定义
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public string DefineAction(string str)
        {
            return "{\"statusCode\":\"201\", \"message\":\"提示：" + str + "\"}";
        }


        /// <summary>
        /// 登陆超时返回的json
        /// </summary>
        /// <returns></returns>
        public static string TimeOut()
        {
            return TimeOut("/Login.html");
        }

        /// <summary>
        /// 登陆超时返回的json
        /// </summary>
        /// <param name="forwardUrl">转到相关页面</param>
        /// <returns></returns>
        public static string TimeOut(string forwardUrl)
        {
            return "{\"statusCode\":\"301\",\"message\":\"登陆超时\",\"targetUrl\":\"" + forwardUrl + "\"}";
        }
        #endregion


    }
}
