﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;


namespace Utility
{
    public class CreateExportExcel
    {
        OperateExcel operateExcel = new OperateExcel();
        //string filePath = ConfigurationManager.AppSettings["UploadPath"].ToString() + "\\" + "reportFiles\\";
        string filePath = ConfigurationManager.AppSettings["UploadFilePath"].ToString();
        string ipAddress = ConfigurationManager.AppSettings["UrlAddress"].ToString();

        public string GetFileName1(DataTable dtList)
        {
            string httpResult = "";

            if (dtList.Rows.Count == 0)
            {
                //没有查询到数据
                return "0";
            }

            //生成Excel文件
            List<string> columnName = new List<string>() { "姓名", "部门", "工号", "班次", "班次时段", "星期", "日期", "开始时间", "结束时间", "打卡开始", "打卡结束", "时长", "修改后时长", "签卡审核状态", "迟到时间", "早退时间", "旷工时长", "放假", "产假", "病假", "有薪假", "请假合计", "请假类别", "宵夜", "签卡次数", "连班", "签卡原因", "异常情况", "备注说明", "在职状态" };

            List<string> dispalyName = new List<string>() { "姓名", "部门", "工号", "班次", "时段", "星期", "日期", "开始时间", "结束时间", "打卡开始", "打卡结束", "时长", "修改后时长", "签卡状态", "迟到", "早退", "旷工", "放假", "产假", "病假", "有薪假", "请假", "请假类别", "宵夜", "签卡次数", "连班", "签卡原因", "异常情况", "备注说明", "在职状态" };
            List<string> columnWidth = new List<string>() { "8", "10", "8", "11", "5", "5", "10", "8", "8", "8", "8", "5", "10", "10", "5", "5", "5", "5", "5", "5", "5", "5", "10", "5", "8", "5", "10", "10", "10", "10" };
            //int(1) double(2) decimal(3) string(4)
            List<string> columnType = new List<string>() { "4", "4", "4", "4", "2", "4", "4", "4", "4", "4", "4", "2", "4", "4", "2", "2", "2", "2", "2", "2", "2", "2", "4", "2", "2", "4", "4", "4", "4", "4" };

            string result = operateExcel.SaveExcelToServer(dtList, columnName, dispalyName, columnWidth, columnType, filePath + "KQDetail.xlsx");

            switch (result)
            {
                case "1":
                    //成功
                    httpResult = ipAddress + @"Uploads\reportFiles\KQDetail.xlsx";
                    break;
                case "3":
                    //其他错误
                    //httpResult = "3";
                    httpResult = result;
                    break;
                default:
                    //其他错误
                    //httpResult = "3";
                    httpResult = result;
                    break;
            }

            return httpResult;
        }


        #region 导出Excel
        /// <summary>
        /// 导出Excel
        /// </summary>
        /// <param name="dtList">表格数据</param>
        /// <param name="dtList2">表头数据</param>
        /// <param name="reportName">导出Excel文件名</param>
        /// <returns></returns>
        public string ExportCommonExcel(DataTable dtList, DataTable dtList2, string reportName)
        {
            string httpResult = "";

            List<string> displayName = new List<string>();
            List<string> columnWidth = new List<string>();
            List<string> columnType = new List<string>();

            //获取导出Excel类型
            getExportExcelType(dtList2, ref displayName, ref columnWidth, ref columnType);

            //生成Excel文件

            //int(1) double(2) decimal(3) string(4)

            //生成Excel文件 
            string result = operateExcel.SaveExcelToServer(dtList, displayName, displayName, columnWidth, columnType, filePath + reportName);

            switch (result)
            {
                case "1":
                    //成功
                    //httpResult = ipAddress + @"Uploads\reportFiles\" + reportName + ".xlsx";
                    httpResult = ipAddress + @"Uploads\" + reportName;
                    break;
                case "3":
                    //其他错误
                    httpResult = "3";
                    break;
                default:
                    //其他错误
                    httpResult = "3";
                    break;
            }
            return httpResult;
        }

        /// <summary>
        /// 导出有两行列头的Excel文件
        /// </summary>
        /// <param name="dtList">表格数据</param>
        /// <param name="dtList2">表头数据</param>
        /// <param name="hashTop">顶层的栏位Hashtable</param>
        /// <param name="hashtable">多表头的层间对应关系</param>
        /// <param name="reportName">导出的Excel文件名</param>
        /// <returns></returns>
        public string ExportTwoHeadRowsExcel(DataTable dtList, DataTable dtList2, Hashtable hashTopTable, Hashtable hashTable, string reportName)
        {
            string httpResult = "";

            List<string> displayName = new List<string>();
            List<string> columnWidth = new List<string>();
            List<string> columnType = new List<string>();

            //获取导出Excel类型
            getExportExcelType(dtList2, ref displayName, ref columnWidth, ref columnType);

            //生成Excel文件

            //int(1) double(2) decimal(3) string(4)

            //生成Excel文件 
            //string result = operateExcel.SaveExcelToServer(dtList, displayName, displayName, columnWidth, columnType, filePath + reportName);
            string result = operateExcel.SaveTwoRowsHeadExcelToServer(dtList, hashTopTable, hashTable, displayName, displayName, columnWidth, columnType, filePath + reportName);

            switch (result)
            {
                case "1":
                    //成功
                    //httpResult = ipAddress + @"Uploads\reportFiles\" + reportName + ".xlsx";
                    httpResult = ipAddress + @"Uploads\" + reportName;
                    break;
                case "3":
                    //其他错误
                    httpResult = "3";
                    break;
                default:
                    //其他错误
                    httpResult = "3";
                    break;
            }
            return httpResult;
        }
        #endregion

        private void getExportExcelType(DataTable dtList, ref List<string> displayName, ref List<string> columnWidth, ref List<string> columnType)
        {
            int columnWidthIndex = 0;
            int columnTypeIndex = 0;
            //for (int i = 0; i < dtList.Rows.Count; i++)
            for (int i = 0; i < dtList.Columns.Count; i++)
            {
                //if (dtList.Rows[i][0].ToString().Trim() == "列类型")
                if (dtList.Columns[i].ToString().Trim() == "DATA_TYPE")
                {
                    columnTypeIndex = i;
                }
                //if (dtList.Rows[i][0].ToString().Trim() == "列宽度")
                if (dtList.Columns[i].ToString().Trim() == "COLUMN_WIDTH")
                {
                    columnWidthIndex = i;
                }

            }

            //for (int j = 2; j < dtList.Columns.Count; j++)
            for (int j = 0; j < dtList.Rows.Count; j++)
            {
                //displayName.Add(dtList.Columns[j].ColumnName);
                displayName.Add(dtList.Rows[j][4].ToString().Trim());
                //columnWidth.Add((Convert.ToInt32(dtList.Rows[columnWidthIndex][j]) / 10).ToString());
                columnWidth.Add((Convert.ToInt32(dtList.Rows[j][columnWidthIndex]) / 10).ToString());
                columnType.Add(dtList.Rows[j][columnTypeIndex].ToString());
            }
            //break;

            //exportTypeList[0].AddRange(displayName);
            //exportTypeList[1].AddRange(columnWidth);
            //exportTypeList[2].AddRange(columnType);

            //return exportTypeList;
        }
    }
}