﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Collections;

namespace Utility
{
    public class DBConnOracle
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public DBConnOracle()
        {
            // 
            // TODO: Add constructor logic here
            //
        }


        /// <summary>
        /// DB Connection
        /// </summary>
        /// <returns></returns>
        private static OracleConnection oracleConn(string connStr)
        {
            OracleConnection conn = new OracleConnection(connStr);
            return conn;
        }


        #region 基础方法
        /// <summary>
        /// 返回結果集的第一行第一列
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sql">SQL 语句</param>
        /// <returns></returns>
        public static string Getscale(string connStr, string sql)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                object obj = cmd.ExecuteScalar();
                //return cmd.ExecuteScalar().ToString();

                if (null != obj)
                    return obj.ToString();
                else
                    return "";
            }
        }

        /// <summary>
        /// 返回第一行第一列
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sql">SQL 语句</param>
        /// <returns></returns>
        public static int ExcuteScalar(string connStr, string sql)
        {
            if (sql.Trim() == "")
            {
                throw new Exception("SQL Is Null.");
            }

            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>
        /// 返回 Select 結果的 DataTable
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sql">sql 语句</param>
        /// <returns></returns>
        public static DataTable GetDataTable(string connStr, string sql)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleDataAdapter da = new OracleDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds.Tables[0];
            }
        }

        /// <summary>
        /// 返回Select 結果的 DataSet
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sql">sql 语句</param>
        /// <returns></returns>
        public static DataSet GetDataSet(string connStr, string sql)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleDataAdapter da = new OracleDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        /// <summary>
        /// 执行 ExceteNoQuery 动作(Insert,Update,Delete)
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sql">SQL 语句</param>
        /// <returns></returns>
        public static void ExcuteNoQuery(string connStr, string sql)
        {
            if (sql.Trim() == "")
            {
                throw new Exception("SQL Is Null.");
            }

            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// 批量执行 SQL
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="SqlList">sql 语句集</param>
        public static void ExcuteNoQuerySS(string connStr, List<string> SqlList)
        {
            if (SqlList.Count == 0)
            {
                throw new Exception("SQL Is Null.");
            }

            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleTransaction tran = conn.BeginTransaction();
                OracleCommand cmd = conn.CreateCommand();
                cmd.Transaction = tran;
                string sql;

                try
                {
                    for (int i = 0; i < SqlList.Count; i++)
                    {
                        sql = SqlList[i];
                        if (sql.Trim() != "")
                        {
                            cmd.CommandText = sql;
                            cmd.ExecuteNonQuery();
                        }
                    }

                    tran.Commit();
                }
                catch (Exception err)
                {
                    tran.Rollback();
                    throw err;
                }
                finally
                {
                    tran.Dispose();
                    cmd.Dispose();
                    conn.Close();
                    conn.Dispose();
                }
            }
        }
        #endregion


        #region 存储过程
        /// <summary>
        /// 通用存储过程查询方法
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回DataTable数据集</returns>
        public static DataTable execPro_DT(string connStr, string ProName, OracleParameter[] pars)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(ProName, conn);
                if (pars != null)
                {
                    OracleParameter p1 = new OracleParameter("result", OracleDbType.RefCursor);
                    p1.Direction = System.Data.ParameterDirection.Output;
                    cmd.Parameters.Add(p1);
                    
                    foreach (OracleParameter par in pars)
                    {
                        if (par.Value != null)
                        {
                            string sPname = par.ParameterName;
                            string sPvalue = par.Value.ToString();

                            OracleParameter pa = new OracleParameter(par.ParameterName, par.Value);
                            cmd.Parameters.Add(pa);
                        }
                    }
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 3600;

                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                da.Fill(ds);
                if (ds.Tables.Count > 0) dt = ds.Tables[0];
                return dt;
            }
        }

        /// <summary>
        /// 通用存储过程查询方法
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回DataTable数据集</returns>
        public static DataTable execProcedure(string connStr, string ProName, OracleParameter[] pars)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(ProName, conn);
                if (pars != null)
                {
                    //OracleParameter p1 = new OracleParameter("result", OracleDbType.RefCursor);
                    //p1.Direction = System.Data.ParameterDirection.Output;
                    //cmd.Parameters.Add(p1);

                    foreach (OracleParameter par in pars)
                    {
                        if (par.Value != null)
                        {
                            string sPname = par.ParameterName;
                            string sPvalue = par.Value.ToString();

                            OracleParameter pa = new OracleParameter(par.ParameterName, par.Value);
                            cmd.Parameters.Add(pa);
                        }
                    }
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 3600;

                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                da.Fill(ds);
                if (ds.Tables.Count > 0) dt = ds.Tables[0];
                return dt;
            }
        }

        /// <summary>
        /// 通用存储过程查询方法
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回DataSet数据集</returns>
        public static DataSet execPro_DS(string connStr, string ProName, OracleParameter[] pars)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(ProName, conn);
                if (pars != null)
                {
                    OracleParameter p1 = new OracleParameter("result", OracleDbType.RefCursor);
                    p1.Direction = System.Data.ParameterDirection.Output;
                    cmd.Parameters.Add(p1);

                    foreach (OracleParameter par in pars)
                    {
                        string sPname = par.ParameterName;
                        string sPvalue = par.Value.ToString();

                        OracleParameter pa = new OracleParameter(par.ParameterName, par.Value);
                        cmd.Parameters.Add(pa);
                    }
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 3600;

                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                return ds;
            }
        }

        /// <summary>
        /// 通用存储过程查询方法，返回首行首列
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回首行首列</returns>
        public static string execPro_Scalar(string connStr, string ProName, OracleParameter[] pars)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(ProName, conn);
                if (pars != null)
                {
                    //OracleParameter p1 = new OracleParameter("result", OracleDbType.RefCursor);
                    OracleParameter p1 = new OracleParameter("result", OracleDbType.Varchar2);
                    p1.Direction = System.Data.ParameterDirection.Output;
                    cmd.Parameters.Add(p1);

                    foreach (OracleParameter par in pars)
                    {
                        string sPname = par.ParameterName;
                        string sPvalue = par.Value.ToString();

                        OracleParameter pa = new OracleParameter(par.ParameterName, par.Value);
                        cmd.Parameters.Add(pa);
                    }
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 3600;

                return cmd.ExecuteScalar().ToString();
            }
        }

        /// <summary>
        /// 通用存储过程执行方法，返回受影响的行数
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回受影响的行数</returns>
        public static int execPro(string connStr, string ProName, OracleParameter[] pars)
        {
            using (OracleConnection conn = DBConnOracle.oracleConn(connStr))
            {
                conn.Open();
                OracleCommand cmd = new OracleCommand(ProName, conn);
                if (pars != null)
                {
                    OracleParameter p1 = new OracleParameter("result", OracleDbType.RefCursor);
                    p1.Direction = System.Data.ParameterDirection.Output;
                    cmd.Parameters.Add(p1);

                    foreach (OracleParameter par in pars)
                    {
                        string sPname = par.ParameterName;
                        string sPvalue = par.Value.ToString();

                        OracleParameter pa = new OracleParameter(par.ParameterName, par.Value);
                        cmd.Parameters.Add(pa);
                    }
                }
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 3600;

                return cmd.ExecuteNonQuery();
            }
        }
        #endregion




        #region 扩展方法
        /// <summary> 
        /// 按照 fieldNames 从 sourceTable 中选择出不重复的行， 
        /// 并且包含 sourceTable 中所有的列。 
        /// </summary> 
        /// <param name="sourceTable">源表</param> 
        /// <param name="fieldNames">字段</param> 
        /// <returns>一个新的不含重复行的DataTable</returns> 
        public static DataTable getDistinctDataTable(DataTable sourceTable, string[] fieldNames)
        {
            DataTable dt = sourceTable.Clone();
            //dt.TableName = tableName;
            string fields = "";
            for (int i = 0; i < fieldNames.Length; i++)
            {
                fields += fieldNames[i] + ",";
            }
            fields = fields.Remove(fields.Length - 1, 1);
            DataRow lastRow = null;
            foreach (DataRow dr in sourceTable.Select("", fields))
            {
                if (lastRow == null || !(RowEqual(lastRow, dr, dt.Columns)))
                {
                    lastRow = dr;
                    dt.Rows.Add(dr.ItemArray);
                }
            }

            return dt;
        }

        /// <summary>
        /// 將傳入的 Table 做 Distinct.
        /// </summary>
        /// <param name="dtSource">源table</param>
        /// <param name="fieldName">要做 group by 的欄位名稱</param>
        /// <returns></returns>
        public static DataTable getDistinctDataTable(DataTable dtSource, string fieldName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(fieldName, dtSource.Columns[fieldName].DataType);

            object lastValue = null;
            foreach (DataRow dr in dtSource.Select("", fieldName))
            {
                if (lastValue == null || !(columnEqual(lastValue, dr[fieldName])))
                {
                    lastValue = dr[fieldName];
                    dt.Rows.Add(new object[] { lastValue });
                }
            }
            return dt;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rowA"></param>
        /// <param name="rowB"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        private static bool RowEqual(DataRow rowA, DataRow rowB, DataColumnCollection columns)
        {
            bool result = true;
            for (int i = 0; i < columns.Count; i++)
            {
                result &= columnEqual(rowA[columns[i].ColumnName], rowB[columns[i].ColumnName]);
            }

            return result;
        }

        /// <summary>
        /// 內用方法，比较两个对象是否相等
        /// </summary>
        /// <param name="lastValue"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        private static bool columnEqual(object lastValue, object p)
        {
            if (lastValue == DBNull.Value && p == DBNull.Value)
            {
                return true;
            }
            if (lastValue == DBNull.Value || p == DBNull.Value)
            {
                return false;
            }

            return (lastValue.Equals(p));
        }
        #endregion

    }
}
