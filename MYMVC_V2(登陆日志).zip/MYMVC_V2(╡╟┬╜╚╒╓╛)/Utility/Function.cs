﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Utility
{
    public class Function
    {
        /// <summary>
        /// 在sSource前加"0"
        /// </summary>
        /// <param name="sSource">原字符串</param>
        /// <param name="iLength">输出字符长度</param>
        /// <returns></returns>
        public static string AddZero(string sSource, int iLength)
        {
            string result = sSource;
            while (result.Length < iLength)
            {
                result = "0" + result;
            }
            return result;
        }

        /// <summary>
        /// 取文件名的扩展名
        /// </summary>
        /// <param name="fileName">文件名</param>
        /// <returns>返回扩展名</returns>
        public static string GetFileExpend(string fileName)
        {
            if(!string.IsNullOrEmpty(fileName))
            {
                int iPos = fileName.LastIndexOf('.');
                if (iPos >= 0)
                    return fileName.Substring(iPos);
                else
                    return "";
            }

            return "";
        }

    }
}