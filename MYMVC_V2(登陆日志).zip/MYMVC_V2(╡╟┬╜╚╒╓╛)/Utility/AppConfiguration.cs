﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Utility
{
    public class AppConfiguration
    {
        #region connectionStrings
        /// <summary>
        /// OA DB
        /// </summary>
        public static string C6
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["C6"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// Medion OA3
        /// </summary>
        public static string OA3Medion
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["OA3Medion"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// Lenovo OA3
        /// </summary>
        public static string OA3Lenovo
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["OA3Lenovo"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// ITSDB
        /// </summary>
        public static string ITSDB
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["ITSConn"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// 100.18 N8503
        /// </summary>
        public static string constrErpother
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["conStrErpother"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// 登陆连接
        /// </summary>
        public static string LoginConn
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["LoginConn"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// 权限连接
        /// </summary>
        public static string PowerConn
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["PowerConn"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        public static string SFC
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["conStrSFC"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        #region SqlSever 链接字符串
        public static string SqlDefault
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["Default"].ToString();
                }
                catch
                {
                    return null;
                }
            }


        }
        #endregion SqlSever 链接字符串

        #region ORACLE 连接字符串
        //三诺数字
        public static string ERPDBToptst
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["ERPDB_Toptst"].ToString();
                }
                catch
                {
                    return null;
                }
            }


        }


        // 信息科技正式库
        public static string ERPDBOracle
        {
            get {
                try
                {
                    return ConfigurationManager.ConnectionStrings["ERPDB_Oracle"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }

        #endregion ORACLE 连接字符串
        public static string EPOOracle
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["EPO_Oracle"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// 外部SRM系统数据库
        /// </summary>
        public static string SrmConn
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["SrmConn"].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }
        #endregion


        #region appSettings
        /// <summary>
        /// Excel 模板文件存放路径
        /// </summary>
        public static string ServerOrigExcelPath
        {
            get { return ConfigurationManager.AppSettings["ServerOrigExcelPath"]; }
        }
        public static string UrlAddress
        {
            get { return ConfigurationManager.AppSettings["UrlAddress"]; }
        }




        /// <summary>
        /// 存储过程参数 Key 个数
        /// </summary>
        public static int ParameterCount
        {
            get
            {
                try
                {
                    return Convert.ToInt32(ConfigurationManager.ConnectionStrings["ParameterCount"].ToString());
                }
                catch
                {
                    return 10;
                }
            }
        }
        /// <summary>
        /// 应用系统标识符
        /// </summary>
        public static string SYSTEM_FLAG
        {
            get { return ConfigurationManager.AppSettings["SYSTEM_FLAG"]; }
        }
        /// <summary>
        /// 临时文件夹，用于暂存用户生成的下载文件
        /// </summary>
        public static string TempDirectory
        {
            get { return ConfigurationManager.AppSettings["TempDirectory"]; }
        }
        #endregion
    }
}
