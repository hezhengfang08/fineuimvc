﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using System.Web.Configuration;
using System.Configuration;
using System.Data;
using System.Collections;

namespace Utility
{
    public static class OperateJson
    {
        #region 将datatable转换为json
        /// <summary>
        /// 将datatable转换为json  
        /// </summary>
        /// <param name="dtb">Dt</param>
        /// <returns>JSON字符串</returns>
        public static string Dtb2Json(DataTable dtb)
        {

            JavaScriptSerializer jss = new JavaScriptSerializer();

            ScriptingJsonSerializationSection section =
              ConfigurationManager.GetSection("system.web.extensions/scripting/webServices/jsonSerialization") as
              ScriptingJsonSerializationSection;
            if (section != null)
            {
                jss.MaxJsonLength = section.MaxJsonLength;
                jss.RecursionLimit = section.RecursionLimit;
            }

            System.Collections.ArrayList dic = new System.Collections.ArrayList();
            foreach (DataRow dr in dtb.Rows)
            {
                System.Collections.Generic.Dictionary<string, object> drow = new System.Collections.Generic.Dictionary<string, object>();
                foreach (DataColumn dc in dtb.Columns)
                {
                    drow.Add(dc.ColumnName, dr[dc.ColumnName]);
                }
                dic.Add(drow);

            }
            //序列化  
            return jss.Serialize(dic);
        }
        #endregion

        #region 反序列化
        /// <summary>
        /// DataTable 转 Model 类集合
        /// </summary>
        /// <typeparam name="T">Model 类</typeparam>
        /// <param name="dt">Dt 记录集</param>
        /// <returns></returns>
        public static List<T> DtToList<T>(DataTable dt)
        {
            return JsonToList<T>(Dtb2Json(dt));
        }
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="JsonStr"></param>
        /// <returns></returns>
        public static List<T> JsonToList<T>(string JsonStr)
        {
            JavaScriptSerializer Serializer = new JavaScriptSerializer();
            List<T> objs = Serializer.Deserialize<List<T>>(JsonStr);
            return objs;
        }
        public static T JsonToObject<T>(string JsonStr)
        {
            JavaScriptSerializer Serializer = new JavaScriptSerializer();
            T objs = Serializer.Deserialize<T>(JsonStr);
            return objs;
        }

        /// <summary>
        /// 反序列化
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="JsonStr"></param>
        /// <returns></returns>
        public static List<T> JSONStringToList<T>(this string JsonStr)
        {
            JavaScriptSerializer Serializer = new JavaScriptSerializer();
            List<T> objs = Serializer.Deserialize<List<T>>(JsonStr);
            return objs;
        }
        #endregion

        #region Json 字符串 转换为 DataTable数据集合
        public static DataTable ToDataTable(this string json)
        {
            DataTable dataTable = new DataTable();  //实例化
            DataTable result;

            try
            {
                JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
                //NetTcpBinding binding = new NetTcpBinding();
                //binding.MaxReceivedMessageSize = 2147483647;

                ScriptingJsonSerializationSection section =
                  ConfigurationManager.GetSection("system.web.extensions/scripting/webServices/jsonSerialization") as
                  ScriptingJsonSerializationSection;
                if (section != null)
                {
                    javaScriptSerializer.MaxJsonLength = section.MaxJsonLength; //取得最大数值
                }
                ArrayList arrayList = javaScriptSerializer.Deserialize<ArrayList>(json);
                if (arrayList.Count > 0)
                {
                    foreach (Dictionary<string, object> dictionary in arrayList)
                    {
                        if (dictionary.Keys.Count<string>() == 0)
                        {
                            result = dataTable;
                            return result;
                        }
                        if (dataTable.Columns.Count == 0)
                        {
                            foreach (string current in dictionary.Keys)
                            {
                                //dataTable.Columns.Add(current, dictionary[current].GetType());
                                dataTable.Columns.Add(current);
                            }
                        }
                        DataRow dataRow = dataTable.NewRow();
                        foreach (string current in dictionary.Keys)
                        {
                            dataRow[current] = dictionary[current];
                        }

                        dataTable.Rows.Add(dataRow); //循环添加行到DataTable中
                    }
                }
            }
            catch (Exception ex)
            {

            }
            result = dataTable;
            return result;
        }
        #endregion

    }
}
