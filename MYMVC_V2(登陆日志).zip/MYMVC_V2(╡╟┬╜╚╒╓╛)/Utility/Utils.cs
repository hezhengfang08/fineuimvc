﻿using System;
using System.Net;
using System.IO;
using System.Web;
using System.Text.RegularExpressions;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace Utility
{
    /// <summary>
    /// 实用工具类
    /// </summary>
    public static class Utils
    {
        #region Http 请求
        /// <summary>
        /// 创建GET方式的HTTP请求
        /// </summary>
        /// <param name="url">Get 请求 URL</param>
        /// <param name="timeout">超时时间，单位毫秒</param>
        /// <returns></returns>
        public static string CreateGetHttpResponse(string url, int timeout)
        {
            HttpWebRequest request = null;
            request = WebRequest.Create(url) as HttpWebRequest;
            request.Timeout = timeout;
            request.Method = "GET";

            HttpWebResponse httpResponse = request.GetResponse() as HttpWebResponse;
            StreamReader sr = new StreamReader(httpResponse.GetResponseStream(), Encoding.GetEncoding("UTF-8"));
            string returnString = sr.ReadToEnd();
            sr.Close();
            return returnString;
        }
        /// <summary>
        /// 创建POST方式的HTTP请求
        /// </summary>
        /// <param name="url">Post 请求 URL</param>
        /// <param name="timeout">超时时间，单位毫秒</param>
        /// <returns></returns>
        public static string CreatePostHttpResponse(string url, int timeout)
        {
            HttpWebRequest request = null;
            request = WebRequest.Create(url) as HttpWebRequest;
            request.Timeout = timeout;
            request.Method = "Post";

            HttpWebResponse httpResponse = request.GetResponse() as HttpWebResponse;
            StreamReader sr = new StreamReader(httpResponse.GetResponseStream(), Encoding.GetEncoding("UTF-8"));
            string returnString = sr.ReadToEnd();
            sr.Close();
            return returnString;
        }


        /// <summary>
        /// Http 通用请求
        /// </summary>
        /// <param name="sUrl">url</param>
        /// <param name="sData">data</param>
        /// <param name="sMethod">Get 或 Post</param>
        /// <returns></returns>
        public static string HttpResponse(string sUrl, string sData, string sMethod)
        {
            try
            {
                Encoding encoding = Encoding.UTF8;
                byte[] data = encoding.GetBytes(sData);

                HttpWebRequest myRequest = (HttpWebRequest)HttpWebRequest.Create(sUrl);
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(CheckValidationResult);   //验证服务器证书回调自动验证
                myRequest.Method = sMethod;
                //myRequest.Timeout = 3000;     //超时时长，单位毫秒
                myRequest.ContentType = "application/x-www-form-urlencoded";
                myRequest.ContentLength = data.Length;
                //myRequest.CookieContainer = cookie;
                
                //NetworkCredential c = new NetworkCredential("3NOD", "Li]49RQ/");
                //myRequest.Credentials = c;

                if (sMethod == "POST")
                {
                    Stream newStream = myRequest.GetRequestStream();
                    newStream.Write(data, 0, data.Length);
                    newStream.Close();
                }

                HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
                StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
                return reader.ReadToEnd();
            }
            catch (Exception err)
            {
                return err.Message;
            }
        }
        public static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {   // 总是接受    
            return true;
        }
        #endregion

        #region Cookie 相关
        /// <summary>
        /// 设置Cookie
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        public static void SetCookie(string cookieName, string strValue)
        {
            strValue = HttpUtility.UrlEncode(strValue);
            HttpCookie cookie = HttpContext.Current.Request.Cookies[cookieName];
            if (cookie == null)
            {
                cookie = new HttpCookie(cookieName);
            }
            cookie.Value = strValue;
            HttpContext.Current.Response.AppendCookie(cookie);
        }
        /// <summary>
        /// 读取Cookie
        /// </summary>
        /// <param name="strName">名称</param>
        /// <returns>cookie值</returns>
        public static string GetCookie(string cookieName)
        {
            if (HttpContext.Current.Request.Cookies != null && HttpContext.Current.Request.Cookies[cookieName] != null)
                return HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies[cookieName].Value.ToString());
            else
                return "";
        }
        /// <summary>
        /// 判断Cookie是否存在
        /// </summary>
        /// <param name="cookieName">Cookie名称</param>
        /// <param name="url">跳转地址</param>
        public static bool CheckCookie(string cookieName)
        {
            if (HttpContext.Current.Request.Cookies[cookieName] == null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(HttpContext.Current.Request.Cookies[cookieName].Value))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// 判断Cookie是否存在,不存在则跳转到指定Url
        /// </summary>
        /// <param name="cookieName">Cookie名称</param>
        /// <param name="url">跳转地址</param>
        public static void CheckCookie(string cookieName, string url)
        {
            if (HttpContext.Current.Request.Cookies[cookieName] == null)
            {
                HttpContext.Current.Response.Redirect(url);
            }
            else
            {
                if (string.Empty == HttpContext.Current.Request.Cookies[cookieName].Value || HttpContext.Current.Request.Cookies[cookieName].Value.Trim() == "")
                {
                    HttpContext.Current.Response.Redirect(url);
                }
            }
        }
        /// <summary>
        /// 清除Cookie
        /// </summary>
        /// <param name="cookieName">Cookie名称</param>
        public static void ClearCookie(string cookieName)
        {
            HttpContext.Current.Response.Cookies[cookieName].Expires = DateTime.Now;
        }
        #endregion


        #region 数据格式转换
        /// <summary>
        /// 将对象转换为Int32类型
        /// </summary>
        /// <param name="str">要转换的字符串</param>
        /// <param name="defValue">缺省值</param>
        /// <returns>转换后的int类型结果</returns>
        public static int StrToInt(string str, int defValue)
        {
            if (string.IsNullOrEmpty(str) || str.Trim().Length >= 11 || !Regex.IsMatch(str.Trim(), @"^([-]|[0-9])[0-9]*(\.\w*)?$"))
                return defValue;

            int rv;
            if (Int32.TryParse(str, out rv))
                return rv;

            return Convert.ToInt32(StrToFloat(str, defValue));
        }

        /// <summary>
        /// string型转换为float型
        /// </summary>
        /// <param name="strValue">要转换的字符串</param>
        /// <param name="defValue">缺省值</param>
        /// <returns>转换后的int类型结果</returns>
        public static float StrToFloat(string strValue, float defValue)
        {
            if ((strValue == null) || (strValue.Length > 10))
                return defValue;

            float intValue = defValue;
            if (strValue != null)
            {
                bool IsFloat = Regex.IsMatch(strValue, @"^([-]|[0-9])[0-9]*(\.\w*)?$");
                if (IsFloat)
                    float.TryParse(strValue, out intValue);
            }
            return intValue;
        }
        #endregion

    }
}
