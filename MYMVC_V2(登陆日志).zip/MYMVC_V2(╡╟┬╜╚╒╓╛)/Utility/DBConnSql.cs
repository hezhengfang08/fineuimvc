﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace Utility
{
    /// <summary>
    /// v1.0
    /// </summary>
    public class DBConnSql
    {
        /// <summary>
        /// 多数据库操作
        /// </summary>
        public DBConnSql()
        {
            // TODO: Add constructor logic here
        }


        /// <summary>
        /// DB Connection For SQL Server
        /// </summary>
        /// <returns></returns>
        public static SqlConnection SqlConn(string connStr)
        {
            SqlConnection conn = new SqlConnection(connStr);
            return conn;
        }


        #region 基础方法
        /// <summary>
        /// 返回結果集的第一行第一列
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static string Getscalar(string connStr, string sql)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            string strResult = "";
            try
            {
                strResult = cmd.ExecuteScalar().ToString();
                conn.Close();
                conn.Dispose();
            }
            catch
            {
                conn.Close();
                conn.Dispose();
            }
            return strResult;
        }

        /// <summary>
        /// 返回最大值
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static int ExcuteScalar(string connStr, string sql)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            int count = 0;
            if (sql.Trim() == "")
            {
                return count;
            }
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                count = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                conn.Dispose();
            }
            catch
            {
                conn.Close();
                conn.Dispose();
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return count;
        }

        /// <summary>
        /// 返回 Select 結果的 DataTable
        /// </summary>
        /// <param name="cmdstr"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string connStr, string cmdstr)
        {
            using (SqlConnection conn = DBConnSql.SqlConn(connStr))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmdstr, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds.Tables[0];
            }
        }

        /// <summary>
        /// 返回Select 結果的 DataSet
        /// </summary>
        /// <param name="cmdstr"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(string connStr, string cmdstr)
        {
            using (SqlConnection conn = DBConnSql.SqlConn(connStr))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmdstr, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        /// <summary>
        /// 執行 ExceteNoQuery 動作(Insert,Update,Delete) 參數為String, 返回 "1" 表示成功
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static string ExcuteNoQuery(string connStr, string sql)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            string str = "1";
            if (sql.Trim() == "")
            {
                return "SQL Is Null";
            }
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                conn.Dispose();
            }
            catch (Exception ed)
            {
                conn.Close();
                conn.Dispose();
                str = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return str;
        }

        /// <summary>
        /// 執行 ExceteNoQuery 動作(Insert,Update,Delete) 參數為String, 返回受影响记录的行数
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static int ExcuteSql(string connStr, string sql)
        {
            if (sql.Trim() == "")
            {
                return 0;
            }

            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();

            int iResult = 0;
            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                iResult = cmd.ExecuteNonQuery();
            }
            catch (Exception ed)
            {
                throw ed;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return iResult;
        }

        /// <summary>
        /// 多条 SQL 事务处理
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="al">SQL 集合</param>
        /// <returns>1：表示成功；否则返回错误信息</returns>
        public static void ExcuteNoQuerySS(string connStr, List<string> SqlList)
        {
            using (SqlConnection conn = DBConnSql.SqlConn(connStr))
            {
                conn.Open();
                SqlTransaction tran = conn.BeginTransaction();
                SqlCommand cmd = conn.CreateCommand();
                cmd.Transaction = tran;

                if (SqlList.Count == 0)
                {
                    throw new Exception("SQL is Null.");
                }

                try
                {
                    string sql;
                    for (int i = 0; i < SqlList.Count; i++)
                    {
                        sql = SqlList[i];
                        if (sql.Trim() != "")
                        {
                            cmd.CommandText = sql;
                            cmd.ExecuteNonQuery();
                        }
                    }

                    tran.Commit();
                }
                catch (Exception err)
                {
                    throw err;
                }
                finally
                {
                    tran.Dispose();
                    cmd.Dispose();
                    conn.Close();
                    conn.Dispose();
                }
            }
        }
        #endregion


        #region 存储过程
        /// <summary>
        /// 执行存储过程，不含事务
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="para">参数</param>
        /// <returns>执行成功返回“1”，否则返回错误信息</returns>
        public static string execStoredProcedure(string connStr, string sp_name, SqlParameter[] para)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            string flag = "1";
            try
            {
                SqlCommand comm = new SqlCommand();
                comm.CommandTimeout = 300;
                comm.Connection = conn;
                comm.CommandText = sp_name;
                comm.CommandType = CommandType.StoredProcedure;

                for (int i = 0; i < para.Length; i++)
                {
                    comm.Parameters.Add(para[i]);
                }
                comm.ExecuteNonQuery();
                flag = "1";
            }
            catch (Exception ex)
            {
                flag = ex.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return flag;
        }

        /// <summary>
        /// 执行存储过程，含事务
        /// </summary>
        /// <param name="connStr">数据库连接字符串</param>
        /// <param name="sp_name">存储过程名称</param>
        /// <param name="para">参数</param>
        /// <returns>执行成功返回“1”，否则返回错误信息</returns>
        public static string execStoredProcedureTrans(string connStr, string sp_name, SqlParameter[] para)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();

            SqlTransaction trans = conn.BeginTransaction(IsolationLevel.Serializable);
            string flag = "1";
            try
            {
                SqlCommand comm = new SqlCommand();
                comm.CommandTimeout = 300;
                comm.Connection = conn;
                comm.Transaction = trans;
                comm.CommandText = sp_name;
                comm.CommandType = CommandType.StoredProcedure;

                for (int i = 0; i < para.Length; i++)
                {
                    comm.Parameters.Add(para[i]);
                }

                trans.Commit();
                flag = "1";
            }
            catch (Exception ex)
            {
                flag = ex.Message;
                trans.Rollback();
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return flag;
        }

        /// <summary>
        /// 執行 StoredProcedure
        /// </summary>
        /// <param name="para">傳入參數以及參數類型</param>
        /// <param name="sp_name">傳入StoredProcedure的名字</param>
        /// <param name="dt">傳入數據table</param>
        /// <param name="column">傳入datatable的欄位名稱,注意step為2.所以column[0]=colname  column[1]="" column[2]=colname column[3]="" and so on...</param>
        /// <param name="parat">OracleType類型參數數組</param>
        /// <returns>如果執行成功,返回true,否則返回false</returns>
        public static bool execStoredProcedureTrans(string connStr, string[] para, string sp_name, DataTable dt, string[] column, System.Data.SqlDbType[] parat)
        {
            bool flag = false;
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            SqlTransaction trans = null;

            try
            {
                conn.Open();
                trans = conn.BeginTransaction(IsolationLevel.Serializable);
                SqlCommand comm = new SqlCommand();
                comm.Connection = conn;
                comm.Transaction = trans;

                comm.CommandText = sp_name;
                comm.CommandType = CommandType.StoredProcedure;


                for (int i = 0; i < para.Length; i++)
                {
                    string cscs = parat[i].ToString();
                    comm.Parameters.Add(para[i], parat[i]);
                }
                for (int n = 0; n < dt.Rows.Count; n++)
                {
                    for (int j = 0; j < para.Length; j++)
                    {
                        // string cc = para[j].Trim();
                        // string bs = column[j].Trim();
                        comm.Parameters[para[j]].Value = dt.Rows[n][column[j]].ToString();
                    }
                    comm.ExecuteNonQuery();
                }
                trans.Commit();
                flag = true;
            }
            catch (Exception ex)
            {
                string str = ex.ToString();
                trans.Rollback();
                conn.Close();
                conn.Dispose();
                flag = false;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return flag;
        }


        ///////////////////////////////////////////////////////////////

        /// <summary>
        /// 通用存储过程查询方法
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回DataTable数据集</returns>
        public static DataTable execPro_DT(string conStr, string ProName, SqlParameter[] pars)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.TableName = "tb";

                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    //创建命令对象
                    SqlCommand cmd = new SqlCommand(ProName, conn);
                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1200;

                    //conn.Open();
                    //SqlDataReader rd = cmd.ExecuteReader();
                    //dt.Load(rd);
                    //rd.Close();
                    //conn.Close();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                return dt;
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        /// <summary>
        /// 通用存储过程查询方法
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回DataSet数据集</returns>
        public static DataSet execPro_DS(string conStr, string ProName, SqlParameter[] pars)
        {
            try
            {
                DataSet ds = new DataSet();

                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    //创建命令对象
                    SqlCommand cmd = new SqlCommand(ProName, conn);
                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1200;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }

                return ds;
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        /// <summary>
        /// 通用存储过程查询方法，返回首行首列内容
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回首行首列内容</returns>
        public static string execPro_Scalar(string conStr, string ProName, SqlParameter[] pars)
        {
            try
            {
                string content = "";

                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    //创建命令对象
                    SqlCommand cmd = new SqlCommand(ProName, conn);
                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }

                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 300;
                    content = cmd.ExecuteScalar().ToString();
                    cmd.Dispose();
                }
                return content;
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        /// <summary>
        /// 通用存储过程执行方法，返回受影响的行数
        /// </summary>
        /// <param name="conStr">连接字符串</param>
        /// <param name="ProName">存储过程名称</param>
        /// <param name="pars">参数</param>
        /// <returns>返回受影响的行数</returns>
        public static int execPro(string conStr, string ProName, SqlParameter[] pars)
        {
            try
            {
                int row = 0;

                using (SqlConnection conn = new SqlConnection(conStr))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand(ProName, conn);

                    if (pars != null)
                    {
                        cmd.Parameters.AddRange(pars);
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    row = cmd.ExecuteNonQuery();
                    conn.Close();
                }

                return row;
            }
            catch (Exception err)
            {
                throw err;
            }
        }
        #endregion




        #region 注释方法
        /*
        /// <summary>
        /// 獲取Sequences 下一個 New ID
        /// </summary>
        /// <param name="strSequences"></param>
        /// <returns></returns>
        public static string GetNewId(string connStr, string strSequences)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            string sql = "select " + strSequences + ".nextval  from dual";
            DataTable dtId = new DataTable();
            dtId = GetDataTable(connStr, sql);
            if (dtId.Rows.Count < 0)
            {
                return "-1";
            }
            else
            {
                sql = dtId.Rows[0][0].ToString();
            }
            dtId.Dispose();
            return sql;
        }

        /// <summary>
        /// 執行 ExceteNoQueryPama 動作帶參數類型的(Insert,Update,Delete) 參數, 返回 "1" 表示成功
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static string ExcuteNoQueryPama(string connStr, SqlCommand cmd)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            string str = "1";
            try
            {
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                conn.Close();
                conn.Dispose();
            }
            catch (Exception ed)
            {
                conn.Close();
                conn.Dispose();
                str = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return str;
        }

        /// <summary>
        /// 執行存儲過程的 ExceteNoQuery 動作(Insert,Update,Delete) 參數為	SqlCommand, 返回 "1" 表示成
        /// </summary>
        /// <param name="ORProc"></param>
        /// <returns></returns>
        public static void ExcuteNoQuery(string connStr, SqlCommand ORProc)
        {
            using (SqlConnection conn = DBConnSql.SqlConn(connStr))
            {
                ORProc.Connection = conn;
                ORProc.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// 兩條 Sql 的事物處理 參數為 string, 返回 "1" 表示成功
        /// </summary>
        /// <param name="sql1"></param>
        /// <param name="sql2"></param>
        /// <returns></returns>
        public static string ExcuteNoQueryS(string connStr, string sql1, string sql2)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            SqlTransaction tran = conn.BeginTransaction();
            SqlCommand cmd = conn.CreateCommand();
            cmd.Transaction = tran;
            string str = "1";
            if (sql1.Trim() == "" && sql2.Trim() == "")
            {
                return "SQL Is Null";
            }
            try
            {
                if (sql1.Trim() != "")
                {
                    cmd.CommandText = sql1;
                    cmd.ExecuteNonQuery();
                }
                if (sql2.Trim() != "")
                {
                    cmd.CommandText = sql2;
                    cmd.ExecuteNonQuery();
                }
                tran.Commit();
                conn.Close();
                conn.Dispose();

            }
            catch (Exception ed)
            {
                tran.Rollback();
                conn.Close();
                conn.Dispose();
                str = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return str;
        }

        /// <summary>
        /// 多條 Sql 事務處理,參數為 Array List, 返回 "1" 表示成功
        /// </summary>
        /// <param name="al"></param>
        /// <returns></returns>
        public static string ExcuteNoQuerySS(string connStr, ArrayList arySQL)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            SqlTransaction tran = conn.BeginTransaction();
            SqlCommand cmd = conn.CreateCommand();
            cmd.Transaction = tran;
            string str = "1";
            if (arySQL.Count == 0)
            {
                return "SQL Is Null";
            }
            try
            {
                string sql;
                for (int i = 0; i < arySQL.Count; i++)
                {
                    sql = (String)arySQL[i];
                    if (sql.Trim() != "")
                    {
                        cmd.CommandText = sql;
                        cmd.ExecuteNonQuery();
                    }
                }

                tran.Commit();
                conn.Close();
                conn.Dispose();

            }
            catch (Exception ed)
            {
                tran.Rollback();
                conn.Close();
                conn.Dispose();
                str = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return str;
        }

        /// <summary>
        /// for batch sql statements
        /// </summary>
        /// <param name="sql"></param>
        /// <returns>message</returns>
        public static string ExcuteBatchSql(string connStr, string[] sql)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            SqlCommand comm = new SqlCommand();
            SqlTransaction trans = null;
            string str = "1";
            int II = 0;
            string cc = "";
            try
            {
                trans = conn.BeginTransaction(IsolationLevel.Serializable);
                comm.Connection = conn;
                comm.Transaction = trans;
                for (int i = 0; i < sql.Length; i++)
                {
                    cc = sql[i].Trim();
                    II = i;
                    comm.CommandText = sql[i].ToString();
                    comm.ExecuteNonQuery();
                }
                trans.Commit();
            }
            catch (Exception ex)
            {
                string cscs = II.ToString();
                string ccccc = cc;

                trans.Rollback();
                comm.Dispose();
                conn.Close();
                conn.Dispose();
                str = ex.ToString();
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            return str;
        }

        /// <summary>
        /// 返回一個裝多個 DataTable / DataSet, 減少訪問DB的次數
        /// </summary>
        /// <param name="sqlBatch">SQL Statement Batch</param>
        /// <param name="tableNameList">DataTable Name List</param>
        /// <returns>DataSet</returns>
        public static DataSet GetDataSet(string connStr, string[] sqlBatch, string[] tableNameList)
        {
            string cmdstr = "";
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            DataSet ds = new DataSet();
            try
            {
                for (int i = 0; i < sqlBatch.Length; i++)
                {
                    DataTable dt = GetDataTable(connStr, sqlBatch[i]);
                    dt.TableName = tableNameList[i];
                    ds.Tables.Add(dt);
                }
                conn.Close();
                conn.Dispose();
            }
            catch (Exception ed)
            {
                conn.Close();
                conn.Dispose();
                cmdstr = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return ds;
        }

        /// <summary>
        /// 返回是否存在的結果 or 獲取統計數量
        /// </summary>
        /// <param name="cmdstr"></param>
        /// <returns></returns>
        public static int CountNum(string connStr, string cmdstr)
        {
            SqlConnection conn = DBConnSql.SqlConn(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand(cmdstr, conn);
            int Count = 0;

            try
            {
                Count = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                conn.Dispose();
            }
            catch (Exception ed)
            {
                conn.Close();
                conn.Dispose();
                cmdstr = ed.Message;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return Count;
        }

        /// <summary>
        /// 將傳入的 Table 做 Distinct.
        /// </summary>
        /// <param name="dtSource">源table</param>
        /// <param name="fieldName">要做 group by 的欄位名稱</param>
        /// <returns></returns>
        public static DataTable getDistinctDataTable(string connStr, DataTable dtSource, string fieldName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(fieldName, dtSource.Columns[fieldName].DataType);

            object lastValue = null;
            foreach (DataRow dr in dtSource.Select("", fieldName))
            {
                if (lastValue == null || !(columnEqual(connStr, lastValue, dr[fieldName])))
                {
                    lastValue = dr[fieldName];
                    dt.Rows.Add(new object[] { lastValue });
                }
            }
            return dt;
        }

        /// <summary> 
        /// 按照 fieldNames 从 sourceTable 中选择出不重复的行， 
        /// 并且包含 sourceTable 中所有的列。 
        /// </summary> 
        /// <param name="sourceTable">源表</param> 
        /// <param name="fieldNames">字段</param> 
        /// <returns>一个新的不含重复行的DataTable</returns> 
        public static DataTable getDistinctDataTable(string connStr, DataTable sourceTable, string[] fieldNames)
        {
            DataTable dt = sourceTable.Clone();
            //dt.TableName = tableName;
            string fields = "";
            for (int i = 0; i < fieldNames.Length; i++)
            {
                fields += fieldNames[i] + ",";
            }
            fields = fields.Remove(fields.Length - 1, 1);
            DataRow lastRow = null;
            foreach (DataRow dr in sourceTable.Select("", fields))
            {
                if (lastRow == null || !(RowEqual(connStr, lastRow, dr, dt.Columns)))
                {
                    lastRow = dr;
                    dt.Rows.Add(dr.ItemArray);
                }
            }
            return dt;
        }

        private static bool RowEqual(string connStr, DataRow rowA, DataRow rowB, DataColumnCollection columns)
        {
            bool result = true;
            for (int i = 0; i < columns.Count; i++)
            {
                result &= columnEqual(connStr, rowA[columns[i].ColumnName], rowB[columns[i].ColumnName]);
            }
            return result;
        }

        /// <summary>
        /// 內用方法
        /// </summary>
        /// <param name="lastValue"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        private static bool columnEqual(string connStr, object lastValue, object p)
        {
            if (lastValue == DBNull.Value && p == DBNull.Value)
            {
                return true;
            }
            if (lastValue == DBNull.Value || p == DBNull.Value)
            {
                return false;
            }
            return (lastValue.Equals(p));

        }
        */
        #endregion

    }
}
