﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aspose.Cells;
using System.Data;
using System.Data.OleDb;
using System.Drawing;

namespace Utility
{
    public class OperateExcel
    {

        #region 保存两行列头的Execl到服务器

        /// <summary>
        /// 保存两行列头的Execl到服务器
        /// </summary>
        /// <param name="dtList">数据源</param>
        /// <param name="hashTop">顶层的栏位Hashtable</param>
        /// <param name="hashtable">多表头的层间对应关系</param>
        /// <param name="ColumnName">字段名</param>
        /// <param name="ColumnWidth">列宽(null时默认为10)</param>
        /// <param name="FileName">文件名(完全路径名)</param>
        /// <param name="columnType">列类型</param>
        public string SaveTwoRowsHeadExcelToServer(System.Data.DataTable dtList, Hashtable hashTop, Hashtable hashTable, List<string> ColumnName, List<string> ColumnChinaName, List<string> ColumnWidth, List<string> columnType, string FileName)
        {
            try
            {
                string path = FileName;

                Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook();
                Aspose.Cells.Worksheet ws = wb.Worksheets[0];
                Cells cell = ws.Cells;

                //定义并获取导出的数据源(以传递的数组列名为依据)
                string[,] SaveDtlist = new string[dtList.Rows.Count, ColumnName.Count];

                for (int i = 0; i < dtList.Rows.Count; i++)
                {
                    for (int j = 0; j < ColumnName.Count; j++)
                    {
                        string sTemp = dtList.Rows[i]["" + ColumnName[j].ToString() + ""].ToString();
                        SaveDtlist[i, j] = sTemp;

                        //SaveDtlist[i, j] = dtList.Rows[i]["" + ColumnName[j].ToString() + ""].ToString();
                    }
                }

                ////合并单元格
                //Aspose.Cells.Range range = cell.CreateRange(0, 0, 1, ColumnName.Count);
                //range.Merge();

                //cell["A1"].PutValue(ReportTitleName);

                //设置行高
                //cell.SetRowHeight(0, 20);

                //设置字体样式
                Aspose.Cells.Style style1 = wb.Styles[wb.Styles.Add()];
                style1.HorizontalAlignment = TextAlignmentType.Center;//文字居中
                style1.Font.Name = "宋体";
                style1.Font.IsBold = true;//设置粗体
                //style1.Font.Size = 12;//设置字体大小

                Aspose.Cells.Style style2 = wb.Styles[wb.Styles.Add()];
                style2.HorizontalAlignment = TextAlignmentType.Left;
                style2.Font.Size = 8;
                style2.ForegroundColor = System.Drawing.Color.FromArgb(0, 176, 80);
                style2.Pattern = BackgroundType.Solid;

                Aspose.Cells.Style style3 = wb.Styles[wb.Styles.Add()];
                //style3.HorizontalAlignment = TextAlignmentType.Right;
                style3.Font.Size = 8;

                Aspose.Cells.Style style4 = wb.Styles[wb.Styles.Add()];
                style4.HorizontalAlignment = TextAlignmentType.Right;
                style4.Number = 1;

                Aspose.Cells.Style style5 = wb.Styles[wb.Styles.Add()];
                style5.HorizontalAlignment = TextAlignmentType.Center;
                style5.Font.Size = 8;
                style5.ForegroundColor = System.Drawing.Color.FromArgb(0, 176, 80);
                style5.Pattern = BackgroundType.Solid;

                //给单元格关联样式
                //cell["A1"].SetStyle(style1); //报表名字 样式

                //////合并单元格
                Aspose.Cells.Range range = null;
                //设置第一行Execl列名
                ArrayList al = new ArrayList(hashTop.Keys);
                al.Sort();

                int startcell = 0;
                for (int i = 0; i < al.Count; i++)
                {
                    int RangeCellCount = 0;
                    foreach (DictionaryEntry de in hashTable)
                    {
                        if (hashTop[al[i]].ToString().Trim() == de.Value.ToString().Trim())
                        {
                            RangeCellCount++;
                        }
                    }
                    range = cell.CreateRange(0, startcell, 1, RangeCellCount);
                    range.Merge();
                    cell[0, startcell].PutValue(hashTop[al[i]].ToString());
                    cell[0, startcell].SetStyle(style5);

                    startcell = startcell + RangeCellCount;
                }

                //设置第二行Execl列名
                for (int i = 0; i < ColumnChinaName.Count; i++)
                {
                    cell[1, i].PutValue(ColumnChinaName[i].ToString());
                    cell[1, i].SetStyle(style2);
                    //ws.AutoFitColumn(i);
                }

                //赋值给Excel内容
                for (int i = 0; i < SaveDtlist.Length / ColumnName.Count; i++)
                {
                    for (int j = 0; j < ColumnName.Count; j++)
                    {
                        try
                        {
                            //int(1) double(2) decimal(3) string(4)
                            if (columnType[j] == "1")
                            {
                                cell[i + 2, j].PutValue(Convert.ToInt32(SaveDtlist[i, j]));
                            }
                            else if (columnType[j] == "2")
                            {
                                cell[i + 2, j].PutValue(Convert.ToDouble(SaveDtlist[i, j]));
                            }
                            else if (columnType[j] == "3")
                            {
                                cell[i + 2, j].PutValue(Convert.ToDecimal(SaveDtlist[i, j]));
                            }
                            else
                            {
                                cell[i + 2, j].PutValue(SaveDtlist[i, j].ToString());
                            }
                            cell[i + 2, j].SetStyle(style3);
                        }
                        catch (Exception e)
                        {
                            //格式转换有误
                            cell[i + 2, j].PutValue(SaveDtlist[i, j]);
                            continue;
                        }
                    }
                }

                //设置列宽
                for (int i = 0; i < ColumnName.Count; i++)
                {
                    if (ColumnWidth == null)
                    {
                        cell.SetColumnWidth(i, 10);
                    }
                    else
                    {
                        cell.SetColumnWidth(i, Convert.ToDouble(ColumnWidth[i].ToString()));

                        //cell.SetColumnWidth(i, ColumnWidth[i]);
                    }
                }

                wb.Save(path);

                return "1";
            }
            catch (Exception ex)
            {
                //BasicMethod.WEBPTLOGRECORD(33, ex.Message);

                //其他错误
                return "3" + ex.Message;
            }
        }
        #endregion 测试

        #region 将Excel转换成datatable
        /// <summary>
        /// 将Excel转换成datatable
        /// </summary>
        /// <param name="strFileName">Excel路径</param>
        /// <returns>返回datatable</returns>
        public static DataTable ExcelImportToDataTable(string strFileName)         //strFileName指定的路径+文件名.xls
        {

            if (strFileName != "")
            {
                string strconn = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + strFileName + ";" + "Extended Properties=Excel 8.0; ";

                OleDbConnection conn = new OleDbConnection(strconn);

                conn.Open();
                ////返回Excel的架构，包括各个sheet表的名称,类型，创建时间和修改时间等  

                ////包含excel中表名的字符串数组
                //string[] strTableNames = new string[dtSheetName.Rows.Count];
                //for (int k = 0; k < dtSheetName.Rows.Count; k++)
                //{
                //    strTableNames[k] = dtSheetName.Rows[k]["TABLE_NAME"].ToString();
                //}
                Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(strFileName);

                string sheetName = workbook.Worksheets[0].Name;

                string sql = "select * from [" + sheetName + "$]";
                OleDbDataAdapter da = new OleDbDataAdapter(sql, strconn);
                DataSet ds = new DataSet();
                try
                {
                    da.Fill(ds, "datatable");

                    DataTable dt = ds.Tables[0];
                }
                catch
                {
                    //MessageBox.Show("操作失败,请检查数据是否有效或已被修改");
                    return null;
                }
                return ds.Tables[0];

            }
            else
            {
                return null;
            }
        }
        #endregion

        #region 将数据插入到指定行列的指定Excel文件中
        /// <summary>
        /// 将数据插入到指定行列的指定Excel文件中
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="col">列</param>
        /// <param name="content">内容</param>
        public void InsertToExcel(DataTable dtList, string operateFilePath, string saveFilePath)
        {
            //Initialize Workbook
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            //Set default font for workbook
            //Aspose.Cells.Style style = workbook.DefaultStyle;

            //style.Font.Name = "Tahoma";
            //workbook.DefaultStyle = style;

            //Aspose.Cells.Worksheet worksheet = workbook.Worksheets[0];
            //Set the name of worksheet
            //worksheet.Name = "Data";
            //worksheet.IsGridlinesVisible = false;

            Cells cells = workbook.Worksheets[0].Cells;
            //向Excel内插入值
            cells = putValueToCells(dtList, cells);


            //range.Borders.get_Item(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeTop).LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlLineStyleNone; 

            //保存Excel文件
            workbook.Save(saveFilePath);
        }
        public void InsertToExcel(HttpResponse Resp, DataTable dtList, string operateFilePath, string saveFileName)
        {
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);
            Cells cells = workbook.Worksheets[0].Cells;

            //向Excel内插入值
            cells = putValueToCells(dtList, cells);


            //保存Excel文件
            //workbook.Save(saveFilePath);  //保存文件到磁盘

            #region 输出到 HttpResponse流
            Resp.Clear();
            Resp.Buffer = true;
            Resp.Charset = "utf-8";
            Resp.AppendHeader("Content-Disposition", "attachment;filename=" + saveFileName);
            Resp.ContentEncoding = System.Text.Encoding.UTF8;
            //Resp.ContentType = "application/vnd.ms-excel";
            Resp.ContentType = "application/ms-excel";
            Resp.BinaryWrite(workbook.SaveToStream().ToArray());
            Resp.End();
            #endregion
        }
        public void InsertToExcel(HttpResponse Resp, int iSheet, DataTable dtList, string operateFilePath, string saveFileName)
        {
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);
            Cells cells = workbook.Worksheets[iSheet].Cells;

            //向Excel内插入值
            cells = putValueToCells(dtList, cells);


            //保存Excel文件
            //workbook.Save(saveFilePath);  //保存文件到磁盘

            #region 输出到 HttpResponse流
            Resp.Clear();
            Resp.Buffer = true;
            Resp.Charset = "utf-8";
            Resp.AppendHeader("Content-Disposition", "attachment;filename=" + saveFileName);
            Resp.ContentEncoding = System.Text.Encoding.UTF8;
            //Resp.ContentType = "application/vnd.ms-excel";
            Resp.ContentType = "application/ms-excel";
            Resp.BinaryWrite(workbook.SaveToStream().ToArray());
            Resp.End();
            #endregion
        }
        public void InsertToExcel(HttpResponse Resp, DataTable dtList, int iSheetCount, string operateFilePath, string saveFileName)
        {
            List<DataTable> dtCollect = new List<DataTable>();

            for (int i = 0; i < iSheetCount; i++)
            {
                DataTable dt = dtList.Clone();

                DataRow[] rows = dtList.Select("EX_SHEET='" + i + "'");
                for (int j = 0; j < rows.Length; j++)
                {
                    //dt.Rows.Add(rows[j]);
                    dt.Rows.Add(rows[j].ItemArray);
                }

                dtCollect.Add(dt);
            }



            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            for (int i = 0; i < dtCollect.Count; i++)
            {
                Cells cells = workbook.Worksheets[i].Cells;
                cells = putValueToCells(dtCollect[i], cells);     //向Excel内插入值
            }


            //保存Excel文件
            //workbook.Save(saveFilePath);  //保存文件到磁盘

            #region 输出到 HttpResponse流
            Resp.Clear();
            Resp.Buffer = true;
            Resp.Charset = "utf-8";
            Resp.AppendHeader("Content-Disposition", "attachment;filename=" + saveFileName);
            Resp.ContentEncoding = System.Text.Encoding.UTF8;
            //Resp.ContentType = "application/vnd.ms-excel";
            Resp.ContentType = "application/ms-excel";
            Resp.BinaryWrite(workbook.SaveToStream().ToArray());
            Resp.End();
            #endregion
        }
        public void InsertToExcel(HttpResponse Resp, DataTable dtList, int iSheetCount, string operateFilePath, string saveFileName, SaveFormat saveFormat)
        {
            List<DataTable> dtCollect = new List<DataTable>();

            for (int i = 0; i < iSheetCount; i++)
            {
                DataTable dt = dtList.Clone();

                DataRow[] rows = dtList.Select("EX_SHEET='" + i + "'");
                for (int j = 0; j < rows.Length; j++)
                {
                    //dt.Rows.Add(rows[j]);
                    dt.Rows.Add(rows[j].ItemArray);
                }

                dtCollect.Add(dt);
            }



            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            for (int i = 0; i < dtCollect.Count; i++)
            {
                Cells cells = workbook.Worksheets[i].Cells;
                cells = putValueToCells(dtCollect[i], cells);     //向Excel内插入值
            }


            workbook.Save(Resp, saveFileName, ContentDisposition.Attachment, new XlsSaveOptions(saveFormat));
        }
        #endregion



        #region 将数据插入到指定行列的指定Excel文件中插入指定数据类型
        /// <summary>
        /// 将数据插入到指定行列的指定Excel文件中插入指定数据类型
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="col">列</param>
        /// <param name="content">内容</param>
        public void InsertToExcelWithType(System.Data.DataTable dtList, string operateFilePath, string saveFilePath)
        {
            //Initialize Workbook
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            Cells cells = workbook.Worksheets[0].Cells;
            //向Excel内插入值
            cells = putValueToCellsWithType(dtList, cells);

            //保存Excel文件
            workbook.Save(saveFilePath);
        }
        #endregion

        #region 将数据插入到指定行列的指定Excel文件中
        /// <summary>
        /// 将数据插入到指定行列的指定Excel文件中
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="col">列</param>
        /// <param name="content">内容</param>
        public void InsertToExcelTwoSheet(System.Data.DataTable dtList, string operateFilePath, string saveFilePath)
        {
            //Initialize Workbook
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            Cells cells0 = workbook.Worksheets[0].Cells;
            Cells cells1 = workbook.Worksheets[1].Cells;
            //向Excel内插入值
            putValueToTwoCells(dtList, cells0, cells1);

            //保存Excel文件
            workbook.Save(saveFilePath);
        }
        #endregion

        #region 将数据完全插入到指定Excel文件中
        /// <summary>
        /// 将数据完全插入到指定Excel文件中
        /// </summary>
        /// <param name="dtList">数据源</param>
        /// <param name="sheetIndex">Excel sheet</param>
        /// <param name="operateFilePath">操作的Excel文件完全路径/param>
        /// <param name="saveFilePath">Excel文件完全保存路径</param>
        public bool InsertToExcel(System.Data.DataTable dtList, int sheetIndex, string operateFilePath, string saveFilePath)
        {
            try
            {
                //Initialize Workbook
                Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook();
                if (operateFilePath != null)
                {
                    workbook = new Aspose.Cells.Workbook(operateFilePath);
                }

                Cells cells = workbook.Worksheets[sheetIndex].Cells;
                //向Excel内插入值
                cells.ImportDataTable(dtList, true, 0, 0);

                //保存Excel文件
                workbook.Save(saveFilePath);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }
        #endregion

        #region 将数据完全插入到指定Excel文件中
        /// <summary>
        /// 将数据完全插入到指定Excel文件中
        /// </summary>
        /// <param name="dtList">数据源</param>
        /// <param name="sheetIndex">Excel Sheet</param>
        /// <param name="operateFilePath">操作的Excel文件路径(可以为null)</param>
        /// <param name="saveFilePath">保存的Excel文件路径(非null)</param>
        /// <param name="startRow">导入Excel开始行(从0开始)</param>
        /// <param name="startColumn">导入Excel开始列(从0开始)</param>
        /// <param name="isFileNameShow">是否导入标题</param>
        /// <returns></returns>
        public bool InsertToExcel(System.Data.DataTable dtList, int sheetIndex, string operateFilePath, string saveFilePath, int startRow, int startColumn, bool isFileNameShow)
        {
            try
            {
                //Initialize Workbook
                Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook();
                if (operateFilePath != null)
                {
                    workbook = new Aspose.Cells.Workbook(operateFilePath);
                }

                Cells cells = workbook.Worksheets[sheetIndex].Cells;
                //向Excel内插入值
                cells.ImportDataTable(dtList, isFileNameShow, startRow, startColumn);

                //保存Excel文件
                workbook.Save(saveFilePath);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }
        #endregion

        /// <summary>
        /// 导入标题到指定Excel文件内
        /// </summary>
        /// <param name="dtList"></param>
        /// <param name="operateFilePath"></param>
        /// <param name="saveFilePath"></param>
        /// <returns></returns>
        /// 
        public bool ExportToTitle(DataTable dtList, string operateFilePath, string saveFilePath)
        {
            try
            {
                Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

                //Set default font for workbook
                //Aspose.Cells.Style style = workbook.DefaultStyle;

                //style.Font.Name = "Tahoma";
                //workbook.DefaultStyle = style;

                Aspose.Cells.Worksheet worksheet = workbook.Worksheets[0];
                //Set the name of worksheet
                //worksheet.Name = "Data";
                //worksheet.IsGridlinesVisible = false;

                Cells cells = workbook.Worksheets[0].Cells;
                //向Excel内插入值
                cells = putValueToCells(dtList, cells);

                //导入标题
                for (int i = 0; i < dtList.Columns.Count; i++)
                {
                    cells[0, i].PutValue(dtList.Rows[i][dtList.Columns[i].ColumnName].ToString());
                }

                //保存Excel文件
                workbook.Save(saveFilePath);

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        #region 保存Execl到服务器
        /// <summary>
        /// 保存Execl到服务器
        /// </summary>
        /// <param name="dtList">数据源</param>
        /// <param name="ColumnName">字段名</param>
        /// <param name="ColumnWidth">列宽(null时默认为10)</param>
        /// <param name="FileName">文件名(完全路径名)</param>
        /// <param name="columnType">列类型</param>
        public string SaveExcelToServer(System.Data.DataTable dtList, List<string> ColumnName, List<string> ColumnChinaName, List<string> ColumnWidth, List<string> columnType, string FileName)
        {
            try
            {
                string path = FileName;

                Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook();
                Aspose.Cells.Worksheet ws = wb.Worksheets[0];
                Cells cell = ws.Cells;

                //定义并获取导出的数据源(以传递的数组列名为依据)
                string[,] SaveDtlist = new string[dtList.Rows.Count, ColumnName.Count];

                for (int i = 0; i < dtList.Rows.Count; i++)
                {
                    for (int j = 0; j < ColumnName.Count; j++)
                    {
                        SaveDtlist[i, j] = dtList.Rows[i]["" + ColumnName[j].ToString() + ""].ToString();
                    }
                }

                ////合并单元格
                //Aspose.Cells.Range range = cell.CreateRange(0, 0, 1, ColumnName.Count);
                //range.Merge();

                //cell["A1"].PutValue(ReportTitleName);

                //设置行高
                //cell.SetRowHeight(0, 20);

                //设置字体样式
                Aspose.Cells.Style style1 = wb.Styles[wb.Styles.Add()];
                style1.HorizontalAlignment = TextAlignmentType.Center;//文字居中
                style1.Font.Name = "宋体";
                style1.Font.IsBold = true;//设置粗体
                //style1.Font.Size = 12;//设置字体大小


                Aspose.Cells.Style style2 = wb.Styles[wb.Styles.Add()];
                style2.HorizontalAlignment = TextAlignmentType.Left;
                style2.Font.Size = 8;
                style2.ForegroundColor = System.Drawing.Color.FromArgb(0, 176, 80);
                style2.Pattern = BackgroundType.Solid;

                Aspose.Cells.Style style3 = wb.Styles[wb.Styles.Add()];
                //style3.HorizontalAlignment = TextAlignmentType.Right;
                style3.Font.Size = 8;

                Aspose.Cells.Style style4 = wb.Styles[wb.Styles.Add()];
                style4.HorizontalAlignment = TextAlignmentType.Right;
                style4.Number = 1;

                //给单元格关联样式
                //cell["A1"].SetStyle(style1); //报表名字 样式


                //设置Execl列名
                for (int i = 0; i < ColumnChinaName.Count; i++)
                {
                    cell[0, i].PutValue(ColumnChinaName[i].ToString());
                    cell[0, i].SetStyle(style2);
                    //ws.AutoFitColumn(i);
                }
                //赋值给Excel内容
                for (int i = 0; i < SaveDtlist.Length / ColumnName.Count; i++)
                {
                    for (int j = 0; j < ColumnName.Count; j++)
                    {
                        try
                        {
                            //int(1) double(2) decimal(3) string(4)
                            if (columnType[j] == "1")
                            {
                                cell[i + 1, j].PutValue(Convert.ToInt32(SaveDtlist[i, j]));
                            }
                            else if (columnType[j] == "2")
                            {
                                cell[i + 1, j].PutValue(Convert.ToDouble(SaveDtlist[i, j]));
                            }
                            else if (columnType[j] == "3")
                            {
                                cell[i + 1, j].PutValue(Convert.ToDecimal(SaveDtlist[i, j]));
                            }
                            else
                            {
                                cell[i + 1, j].PutValue(SaveDtlist[i, j].ToString());
                            }
                            cell[i + 1, j].SetStyle(style3);
                        }
                        catch (Exception e)
                        {
                            //格式转换有误
                            cell[i + 1, j].PutValue(SaveDtlist[i, j]);
                            continue;
                        }


                    }
                }

                //设置列宽
                for (int i = 0; i < ColumnName.Count; i++)
                {
                    if (ColumnWidth == null)
                    {
                        cell.SetColumnWidth(i, 10);
                    }
                    else
                    {
                        cell.SetColumnWidth(i, Convert.ToDouble(ColumnWidth[i].ToString()));

                        //cell.SetColumnWidth(i, ColumnWidth[i]);
                    }

                }

                wb.Save(path);

                return "1";
            }
            catch (Exception ex)
            {
                //BasicMethod.WEBPTLOGRECORD(169, ex.Message);

                //其他错误
                return ex.Message;
            }


        }
        #endregion

        #region 将Excel文件内容转换成DataTable数据
        /*
        /// <summary>
        /// 将Excel文件内容转换成DataTable数据
        /// </summary>
        /// <param name="filePath">文件完全路径</param>
        /// <param name="sheet">sheet号</param>
        /// <param name="needColumnName">是否导出列名</param>
        /// <returns></returns>
        public DataTable ExcelToDT(string filePath, int sheet, bool needColumnName)
        {
            DataTable dtList = new DataTable();

            Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(filePath);
            Aspose.Cells.Worksheet ws = wb.Worksheets[sheet];
            Cells cell = ws.Cells;

            //获取第一列共多少行
            //int rows = cell.GetLastDataRow(0);    //以首列为基准，取最后一行行数
            int rows = cell.Rows.Count;             //取包括标题行行数，以最大行数列为基准
            rows--;     //排除标题行
            int columns = cell.MaxColumn;
            //if (columns > 51)
            //{
            //    columns = 51;
            //}

            dtList = cell.ExportDataTable(0, 0, rows + 1, columns + 1, needColumnName);
            //dtList = cell.ExportDataTable(0, 0, rows + 1, columns + 1, false);
            return dtList;
        }

        /// <summary>
        /// 将Excel文件内容转换成DataTable数据
        /// </summary>
        /// <param name="filePath">文件完全路径</param>
        /// <param name="sheet">sheetName</param>
        /// <param name="needColumnName">是否导出列名</param>
        /// <returns></returns>
        public DataTable ExcelToDT(string filePath, string sheetName, bool needColumnName)
        {
            DataTable dtList = new DataTable();

            Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(filePath);
            Aspose.Cells.Worksheet ws = wb.Worksheets[sheetName];
            Cells cell = ws.Cells;

            //获取第一列共多少行
            int rows = cell.GetLastDataRow(0);
            //int rows = cell.Rows.Count;
            int columns = cell.MaxColumn;
            //if (columns > 51)
            //{
            //    columns = 51;
            //}

            dtList = cell.ExportDataTable(0, 0, rows + 1, columns + 1, needColumnName);
            //dtList = cell.ExportDataTable(0, 0, rows + 1, columns + 1, false);
            return dtList;
        }
        */
        #endregion

        #region 获取Excel文件Sheet名
        /// <summary>
        /// 获取Excel文件Sheet名
        /// </summary>
        /// <param name="filePath">文件完全路径</param>
        /// <param name="sheet">sheet号</param>
        /// <returns></returns>
        public DataTable GetExcelSheetName(string filePath)
        {
            DataTable dtList = new DataTable("tb");
            dtList.Columns.Add("SheetName");

            Aspose.Cells.Workbook wb = new Aspose.Cells.Workbook(filePath);

            int sheetCount = wb.Worksheets.Count;
            for (int i = 0; i < sheetCount; i++)
            {
                dtList.Rows.Add(wb.Worksheets[i].Name);
            }
            return dtList;

        }
        #endregion


        private Cells putValueToCells(System.Data.DataTable dtList, Cells cells)
        {
            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                if (dtList.Rows[i]["EX_VALUE"].ToString().Contains("SAY TOTAL"))
                {
                    //合并单元格
                    Aspose.Cells.Range range = cells.CreateRange(Convert.ToInt32(dtList.Rows[i]["EX_ROW"].ToString()) - 1, 0, 1, 10);
                    range.Merge();
                    range.SetOutlineBorder(BorderType.TopBorder, CellBorderType.Double, Color.Black);
                }

                cells[Convert.ToInt32(dtList.Rows[i]["EX_ROW"].ToString()) - 1, Convert.ToInt32(dtList.Rows[i]["EX_COL"].ToString()) - 1].PutValue(dtList.Rows[i]["EX_VALUE"].ToString());
            }

            return cells;
        }

        private Cells putValueToCellsWithType(System.Data.DataTable dtList, Cells cells)
        {
            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                string TYPE = dtList.Rows[i]["TYPE"].ToString();
                switch (TYPE)
                {
                    //字符类型
                    case "1":
                        cells[Convert.ToInt32(dtList.Rows[i]["ROW"].ToString()) - 1, Convert.ToInt32(dtList.Rows[i]["COL"].ToString()) - 1].PutValue(dtList.Rows[i]["VALUE"].ToString());
                        break;
                    //数字类型
                    case "2":
                        cells[Convert.ToInt32(dtList.Rows[i]["ROW"].ToString()) - 1, Convert.ToInt32(dtList.Rows[i]["COL"].ToString()) - 1].PutValue(Convert.ToDouble(dtList.Rows[i]["VALUE"]));
                        break;
                    default:
                        break;
                }

            }

            return cells;
        }

        private void putValueToTwoCells(System.Data.DataTable dtList, Cells cells0, Cells cells1)
        {
            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                //if (dtList.Rows[i]["VALUE"].ToString().Contains("SAY TOTAL"))
                //{
                //    //合并单元格
                //    Aspose.Cells.Range range = cells0.CreateRange(Convert.ToInt32(dtList.Rows[i]["ROW"].ToString()) - 1, 0, 1, 10);
                //    range.Merge();
                //    range.SetOutlineBorder(BorderType.TopBorder, CellBorderType.Double, Color.Black);
                //}
                string SheetID = dtList.Rows[i]["SheetID"].ToString();
                switch (SheetID)
                {
                    case "0":
                        cells0[Convert.ToInt32(dtList.Rows[i]["ROW"].ToString()) - 1, Convert.ToInt32(dtList.Rows[i]["COL"].ToString()) - 1].PutValue(dtList.Rows[i]["VALUE"].ToString());
                        break;
                    case "1":
                        cells1[Convert.ToInt32(dtList.Rows[i]["ROW"].ToString()) - 1, Convert.ToInt32(dtList.Rows[i]["COL"].ToString()) - 1].PutValue(dtList.Rows[i]["VALUE"].ToString());
                        break;
                    default:
                        break;
                }

            }

            //return cells0;
        }

        #region 下载Excel文件
        /// <summary>
        /// 下载Excel文件
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <param name="fileName">文件名称</param>
        /// <returns>返回下载是否成功</returns>
        public bool DownExcel(string filePath, string fileName)
        {

            ////this.SaveLogTo(tmpLogFile);//save log to a temp file 'tmpLog.txt'
            try
            {
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.ClearHeaders();
                HttpContext.Current.Response.ContentType = "text/plain";
                HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
                HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + fileName);
                HttpContext.Current.Response.WriteFile(filePath);
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.Close();

                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }
        #endregion

        #region 生成销售预测文件表头模板
        /// <summary>
        /// 生成销售预测文件表头模板
        /// </summary>
        /// <param name="row">行</param>
        /// <param name="col">列</param>
        /// <param name="content">内容</param>
        public void CreateSalesFile(System.Data.DataTable dtList, string operateFilePath, string saveFilePath)
        {
            //Initialize Workbook
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(operateFilePath);

            Cells cells = workbook.Worksheets[0].Cells;

            Aspose.Cells.Style style2 = workbook.Styles[workbook.Styles.Add()];
            style2.HorizontalAlignment = TextAlignmentType.Left;
            style2.Font.Size = 10;
            style2.ForegroundColor = System.Drawing.Color.FromArgb(0, 176, 80);
            style2.Pattern = BackgroundType.Solid;

            //向Excel内插入值
            //cells = putValueToCellsWithType(dtList, cells);

            for (int i = 0; i < dtList.Rows.Count; i++)
            {
                string VALUE = dtList.Rows[i][0].ToString();
                cells[0, (i + 4)].PutValue(VALUE);
                cells[0, (i + 4)].SetStyle(style2);
                cells[1, (i + 4)].PutValue(0);

            }

            //保存Excel文件
            workbook.Save(saveFilePath);
        }
        #endregion

        #region 导出excel 测试
        /// <summary>
        /// 导出数据到 Excel（.xlsx）
        /// </summary>
        /// <param name="Resp">HttpResponse响应对象</param>
        /// <param name="dt">要导出的数据</param>
        /// <param name="filename">保存文件名</param>
        public static void CreateExcel(DataTable dt, string filename)
        {
            Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook();
            Aspose.Cells.Worksheet sheet = workbook.Worksheets[0];
            //sheet.FreezePanes(1, 1, 1, 0);

            Aspose.Cells.StyleFlag flag = new Aspose.Cells.StyleFlag();
            flag.All = true;
            //flag.HorizontalAlignment = true;

            #region 样式2  列名行样式
            Aspose.Cells.Style style2 = workbook.Styles[workbook.Styles.Add()];  //新增样式
            style2.HorizontalAlignment = TextAlignmentType.Center;  //文字居中
            style2.Font.Name = "Arial";     //字体
            style2.Font.Size = 10;          //文字大小
            style2.ForegroundColor = Color.FromArgb(128, 128, 128);     //背景色，必须同时设定Pattern才生效
            style2.Font.Color = Color.White;    //字体颜色
            style2.Font.IsBold = true;      //粗体
            style2.IsTextWrapped = false;    //单元格内容自动换行
            style2.Pattern = Aspose.Cells.BackgroundType.Solid;     //边框类型
            style2.Borders.SetColor(Color.FromArgb(169, 169, 169)); //边框颜色
            style2.Borders[BorderType.LeftBorder].LineStyle = CellBorderType.Thin;
            style2.Borders[BorderType.RightBorder].LineStyle = CellBorderType.Thin;
            style2.Borders[BorderType.TopBorder].LineStyle = CellBorderType.Thin;
            style2.Borders[BorderType.BottomBorder].LineStyle = CellBorderType.Thin;
            //style2.Number = 9;
            #endregion


            //for (int i = 0; i < dt.Columns.Count; i++)
            //{
            //    sheet.Cells.SetColumnWidth(i, 20);      //设置列宽
            //}


            sheet.Cells.ImportDataTable(dt, true, "A1");
            sheet.AutoFitColumns();                         //自适应宽度，需在填充数据后调用
            sheet.Cells.ApplyRowStyle(0, style2, flag);
            

            workbook.Save(filename,new XlsSaveOptions(SaveFormat.Xlsx));
            
            //string sExName = FileMgr.GetFileExpend(filename);
            //switch (sExName.ToLower())
            //{
            //    case ".csv":
            //        workbook.Save(Resp, filename, ContentDisposition.Attachment, new XlsSaveOptions(SaveFormat.CSV));
            //        break;
            //    case ".xlsx":
            //        workbook.Save(Resp, filename, ContentDisposition.Attachment, new XlsSaveOptions(SaveFormat.Xlsx));
            //        break;
            //    case ".pdf":
            //        workbook.Save(Resp, filename, ContentDisposition.Attachment, new XlsSaveOptions(SaveFormat.Pdf));
            //        break;

            //    default:
            //        workbook.Save(Resp, filename, ContentDisposition.Attachment, new XlsSaveOptions());
            //        break;
            //}
        }

        #endregion 
    }
}