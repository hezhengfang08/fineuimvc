﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utility
{
    public class OrderModelLenovo
    {
        public string CREATE_DATE { get; set; }
        public string CREATE_USER { get; set; }
        public string OBJECT_ID { get; set; }
        public string POSTING_DATE { get; set; }
        public string SRC_OBJECT_ID { get; set; }
        public string VENDOR_PO { get; set; }
        public string STAT { get; set; }
        public string ZPLANT { get; set; }
        public string ZDOCTYPE { get; set; }
        public string ZSPCOMPIND { get; set; }
        public string ZGSID { get; set; }
        public string ZPURORG { get; set; }
        public string ZCUSNUM { get; set; }
        public string ZDLMSG { get; set; }
        public string ZSPCOND { get; set; }
        public string ZTRANMETD { get; set; }
        public string ZCUSODTS { get; set; }
        public string ZSHIPINST1 { get; set; }
        public string SV_ADDRESS1 { get; set; }
        public string SV_ADDRESS2 { get; set; }
        public string SV_ADDRESS3 { get; set; }
        public string SV_ADDRESS4 { get; set; }
        public string SV_STREET { get; set; }
        public string SV_CITY { get; set; }
        public string SV_REGION { get; set; }
        public string SV_COUNTRY { get; set; }
        public string SV_POSTAL_CODE { get; set; }
        public string SV_ATTENTION { get; set; }
        public string ST_ADDRESS1 { get; set; }
        public string ST_ADDRESS2 { get; set; }
        public string ST_ADDRESS3 { get; set; }
        public string ST_ADDRESS4 { get; set; }
        public string ST_STREET { get; set; }
        public string ST_CITY { get; set; }
        public string ST_REGION { get; set; }
        public string ST_COUNTRY { get; set; }
        public string ST_POSTAL_CODE { get; set; }
        public string ST_ATTENTION { get; set; }
        public string ZSTPNAME { get; set; }
        public string ZSTPNAME2 { get; set; }
        public string ZSTPNAME3 { get; set; }
        public string ZSTPNAME4 { get; set; }
        public string ZSTPL1ST { get; set; }
        public string ZSTPL2ST { get; set; }
        public string ZSTPL34BOXST { get; set; }
        public string ZSTPL5CITY { get; set; }
        public string ZSTPL6 { get; set; }
        public string ZSTPL7PC { get; set; }
        public string ZSTPCOO { get; set; }
        public string ZSTPPHONE { get; set; }
        public string SOLDTOPARTY { get; set; }
        public string ZCUSTNUM { get; set; }
        public string ZCUSTOES { get; set; }
        public string ZEFPONUMB { get; set; }
        public string ZCUST_PHONE { get; set; }
        public string ZCUST_REMARK { get; set; }
        public string ZORDERSYS { get; set; }
        public string NUMBER_EXT { get; set; }
        public string ORDERED_PROD { get; set; }
        public string DESCRIPTION { get; set; }
        public string QUANTITY { get; set; }
        public string PRICE { get; set; }
        public string VALUE { get; set; }
        public string QUAN_CF { get; set; }
        public string DELIV_DATE { get; set; }
        public string ZEAN { get; set; }
        public string ZCOMM { get; set; }
        public string ZKDMAT { get; set; }
        public string ZDLGRP { get; set; }
        public string ZSPITMIND { get; set; }
        public string ZSONUM { get; set; }
        public string ZSOITM { get; set; }
        public string ZECLIPONUM { get; set; }
        public string ZCONTRNUM { get; set; }
        public string ZSCACCD { get; set; }
        public string ZDLPRIO { get; set; }
        public string ZEMAIL { get; set; }
        public string ZCCAD { get; set; }
        public string ZRMAD { get; set; }
        public string ZCRAD { get; set; }
        public string ZCMAD { get; set; }
        public string ZRSD { get; set; }
        public string ZCSD { get; set; }
        public string INCOTERM_KEY { get; set; }
        public string UNIT { get; set; }
        public string CURRENCY { get; set; }
        public string ZVASSMF { get; set; }
        public string ZVASFINPF { get; set; }
        public string ZVASSMLIN { get; set; }
        public string ZVASINSTR { get; set; }
        public string ZVASACCODE { get; set; }
        public string ZCUSADD { get; set; }
        public string ZCUSADD_BEZ { get; set; }
        public string Z8D_P_N { get; set; }
        public string ZMATERGRP1 { get; set; }
        public string ZSALEORG { get; set; }
        public string ZSALEOFF { get; set; }
        public string Z3PONO { get; set; }
        public string ZMFGNO { get; set; }
        public string ZCOMNAME { get; set; }
        public string ZCUSPOCNAME { get; set; }
        public string ZCUSPOCNO { get; set; }
        public string ZOTHER { get; set; }
        public string ZMRP { get; set; }
        public string ZREFID { get; set; }
        public string ZJAN { get; set; }
        public string ZJAN_CAT { get; set; }
    }
}
