﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Utility
{
    public class UserInfo
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Mobile { get; set; }
        public DateTime Birthday { get; set; }
    }


    public class DataOfUser
    {
        [XmlElement(ElementName = "User")]
        public List<UserInfo> list = new List<UserInfo>();
    }


    public class UsersModel
    {
        public UserInfo Users { get; set; }
    }


}
