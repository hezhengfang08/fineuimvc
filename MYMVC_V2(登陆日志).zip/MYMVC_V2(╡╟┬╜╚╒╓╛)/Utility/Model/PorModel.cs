﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utility
{
    public class PorModel
    {
        public DateTime? CREATE_DATE { get; set; }
        public string CREATE_USER { get; set; }
        public string MODEL_NUMBER { get; set; }
        public string MODEL_NAME { get; set; }
        public string DESCRIPTION { get; set; }
        public string TEMP_PN { get; set; }
        public string ECN_NUMBER { get; set; }
        public DateTime? ECN_CREATE_TIME { get; set; }
        public string STATUS { get; set; }
        public DateTime? QUALIFICATION_DATE { get; set; }
        public DateTime? EOW_DATE { get; set; }
        public DateTime? ANNOUNCE_DATE { get; set; }
        public DateTime? GA_DATE { get; set; }
        public string CONFIGURABLE_PART { get; set; }
        public string SUB_SERIES { get; set; }
        public string MT_NUMBER { get; set; }
        public string MT_NAME { get; set; }
        public string CODE_NAME { get; set; }
        public string GEO { get; set; }
        public string BASE_WARRANTY_DESCRIPTION { get; set; }
        public string LAUNCH_EVENT { get; set; }
        public string IAL_NUMBER { get; set; }
        public string GLOBAL_MODEL { get; set; }
        public string SVT_MODEL { get; set; }
        public DateTime? CREATED_ON { get; set; }
        public DateTime? EOL_DATE { get; set; }
        public DateTime? EOS_DATE { get; set; }
        public string PRODUCT_HIERARCHY { get; set; }
        public string LOCATION_CODE { get; set; }
        public string USAGE_CODE { get; set; }
        public string PLANNING_MATERIAL { get; set; }
        public string CREATED_BY { get; set; }
        public string MODIFIED_BY { get; set; }
        public DateTime? LAST_MODIFIED { get; set; }
        public string VERSION { get; set; }
        public string UPC_EAN_JAN_CODE { get; set; }
        public string UPC_EAN_JAN_TYPE { get; set; }
        public string TOP_SELLER { get; set; }
        public string OTHER1 { get; set; }
        public string OTHER2 { get; set; }
        public string OTHER3 { get; set; }
        public string OTHER4 { get; set; }
        public string OTHER5 { get; set; }
        public string OTHER6 { get; set; }
        public string COLOR { get; set; }
        public string DISPLAY_TYPE { get; set; }
        public string KB_BACKLIGHT { get; set; }
        public string KEYBOARD { get; set; }
        public string SECOND_KEYBOARD { get; set; }
        public string LANGUAGE { get; set; }
        public string PALM_REST { get; set; }
        public string SURFACE_TREATMENT { get; set; }
        public string BASE { get; set; }
        public string PROCESSOR { get; set; }
        public string PROCESSOR_AMD { get; set; }
        public string PROCESSOR_CP { get; set; }
        public string CHIPSET { get; set; }
        public string SOUTH_BRIDGE_CHIPSET { get; set; }
        public string HARD_DRIVE { get; set; }
        public string SSD { get; set; }
        public string REPLACE_MEMORY { get; set; }
        public string ONBOARD_RAM { get; set; }
        public string OPTICAL_DEVICE { get; set; }
        public string OFFICE { get; set; }
        public string OPERATING_SYSTEM { get; set; }
        public string BLUETOOTH { get; set; }
        public string CAMERA { get; set; }
        public string BATTERY { get; set; }
        public string ADAPTER { get; set; }
        public string APS { get; set; }
        public string ETHERNET { get; set; }
        public string FINGER_PRINT { get; set; }
        public string GPS { get; set; }
        public string HDMI { get; set; }
        public string MICROPHONE { get; set; }
        public string MODEM { get; set; }
        public string MOUSE { get; set; }
        public string NFC { get; set; }
        public string PMMA { get; set; }
        public string REMOTE_CONTROLLER { get; set; }
        public string TV_TUNER { get; set; }
        public string USB { get; set; }
        public string USIM_CARD_SLOT { get; set; }
        public string NBWARRANTY { get; set; }
        public string APPLICATION { get; set; }
        public string SPECIALCHAR { get; set; }
        public string VGA { get; set; }
        public string WIRELESS_LAN_ADAPTERS { get; set; }
        public string WIRELESS_WAN { get; set; }
        public string WEB_PUBLISH { get; set; }
        public string SHIPPING_COUNTRY { get; set; }
        public string SERVICE1 { get; set; }
        public string SERVICE2 { get; set; }
        public string SERVICE4 { get; set; }
        public string SERVICE7 { get; set; }
        public string SERVICE8 { get; set; }
        public string CARRY_CASE { get; set; }
        public string A_COVER { get; set; }
        public string G3_ANTENNA { get; set; }
        public string USIM { get; set; }
        public string TCM { get; set; }
        public string SOFTWARE { get; set; }
        public string KB_LIGHT { get; set; }
        public string MARKETING_OS { get; set; }
        public string EMMC { get; set; }
        public string CECP { get; set; }
        public string MARKETINGNAME { get; set; }

    }
}
